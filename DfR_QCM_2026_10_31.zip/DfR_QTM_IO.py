import numpy as np
import DfR_QTM_Core as Cor
import os
import tkinter as tk
import pandas as pd
import shutil

def Get_Labels(): 
    global Graph_Labels,header_Labels_Rheo,header_Labels_Model
    Graph_Labels = {}; header_Labels_Rheo = {}; header_Labels_Model = {}
    header_Labels_Model['t']      = 'thickness[nm]'
    header_Labels_Model['PLExp1'] = 'beta\''
    header_Labels_Model['PLExp2'] = 'beta\'\''
    header_Labels_Model['Par1']   = 'J\'[MPa^-1]'  
    header_Labels_Model['Par2']   = 'J\'\'[MPa^-1]'

    Graph_Labels['t']      = 'thickn[nm]'
    Graph_Labels['PLExp1'] = '$\\beta^{\prime}$'
    Graph_Labels['PLExp2'] = '$\\beta^{\prime\prime}$'
    
    header_Labels_Rheo['PLExp1'] = 'beta\''
    header_Labels_Rheo['PLExp2'] = 'beta\'\''
    if Cor.RheoType == 'Jp_Jpp' : 
        Graph_Labels['Par1'] = '$J^{\prime}$ [MPa$^{-1}$]'  
        Graph_Labels['Par2'] = '$J^{\prime\prime}$ [MPa$^{-1}$]'
        header_Labels_Rheo['Par1']   = 'J\'[MPa^-1]'  
        header_Labels_Rheo['Par2']   = 'J\'\'[MPa^-1]'
    if Cor.RheoType == 'Gp_Gpp' : 
        Graph_Labels['Par1'] = '$G^{\prime}$ [MPa]'  
        Graph_Labels['Par2'] = '$G^{\prime\prime}$ [MPa]'  
        header_Labels_Rheo['Par1']   = 'G\'[MPa]'  
        header_Labels_Rheo['Par2']   = 'G\'\'[MPa]'  
    if Cor.RheoType == 'etap_etapp' : 
        Graph_Labels['Par1'] = '$\eta^{\prime}$ [mPa s]'  
        Graph_Labels['Par2'] = '$\eta^{\prime\prime}$ [mPa s]' 
        header_Labels_Rheo['Par1']   = 'eta\'[mPa_s]'  
        header_Labels_Rheo['Par2']   = 'eta\'\'[mPa_s]'  
    if Cor.RheoType == 'Gp_etap' : 
        Graph_Labels['Par1'] = '$G^{\prime}$ [MPa]'  
        Graph_Labels['Par2'] = '$\eta^{\prime}$ [mPa s]'
        header_Labels_Rheo['Par1']   = 'G\'[MPa]'  
        header_Labels_Rheo['Par2']   = 'eta\'[mPa_s]' 
    if Cor.RheoType == '|J|_tandel' : 
        Graph_Labels['Par1'] = '$|J|$ [MPa$^{-1}$]'  
        Graph_Labels['Par2'] = 'tan $\delta$'  
        header_Labels_Rheo['Par1']   = '|J|[MPa^-1]'  
        header_Labels_Rheo['Par2']   = 'tan_delta'  
    if Cor.RheoType == '|G|_tandel' : 
        Graph_Labels['Par1'] = '$|G$| [MPa]' 
        Graph_Labels['Par2'] = 'tan $\delta$'  
        header_Labels_Rheo['Par1']   = '|G|[MPa]' 
        header_Labels_Rheo['Par2']   = 'tan_delta'  
    if Cor.RheoType == '|eta|_tandel' : 
        Graph_Labels['Par1'] = '|$\eta$| [mPa s]'
        Graph_Labels['Par2'] = 'tan $\delta$'
        header_Labels_Rheo['Par1']   = '|eta|_[mPa_s]'
        header_Labels_Rheo['Par2']   = 'tan_delta'

def Get_FParnames(): 
    global FParnames 
    FParnames = []
    for Key in Cor.RheoParKeys:
        if Cor.IncInFits[Key] == 1:
            name = header_Labels_Rheo[Key].replace('[','_')
            name = name.replace(']','')
            name = name.replace('\'','p')
            name = name.replace('|','')
            name = name.replace('(','')
            name = name.replace(')','')
            name = name.replace('^','')
            name = name.replace('-','_m')
            name = name.replace(' ','')
            FParnames.append(name)

def Analyze_header_line_QTZ(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['df_1.','df_3.','df_5.','df_7.','df_9.','df_11.','df_13.']
    count = 0
    i_cols = np.zeros((Cor.novt),dtype=int)
    for iovt in range(Cor.novt):
        if SearchTerms[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + 2 * count
            count += 1

def Analyze_header_line_PyQTZ(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    i_cols    = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['5 MHz','15 MHz','25 MHz','35 MHz','45 MHz','55 MHz','65 MHz']
    count = 0
    for iovt in range(Cor.novt):
        if SearchTerms[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 2 + 2 * count
            count += 1
    Calc_rms_noise_Dfbyn()

def Analyze_header_line_OpenQCM(line):
    global Do_Import,i_cols
    line.split('\t')
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['Frequency_0',
                   'Frequency_1',
                   'Frequency_2',
                   'Frequency_3',
                   'Frequency_4',
                   'Frequency_5',
                   'Frequency_6']
    count = 0
    i_cols = np.zeros((Cor.novt),dtype=int)
    line_splits = line.split(',')
    for iovt in range(Cor.novt):
        for icol_split,line_split in enumerate(line_splits):
            if SearchTerms[iovt] in line_split: 
                Do_Import[iovt] = 1
                i_cols[iovt] = icol_split
                count += 1

def Analyze_header_line_QCMI(line):
    global Do_Import,i_cols
    line.split('\t')
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['Fundamental Frequency Variation',
                   ' 3. ORheortone Variation',
                   '5. ORheortone Variation',
                   '7. ORheortone Variation',
                   '9. ORheortone Variation',
                   '11. ORheortone Variation',
                   '13. ORheortone Variation']
    count = 0
    i_cols = np.zeros((Cor.novt),dtype=int)
    line_splits = line.split('\t')
    for iovt in range(Cor.novt):
        for icol_split,line_split in enumerate(line_splits):
            if SearchTerms[iovt] in line_split: 
                Do_Import[iovt] = 1
                i_cols[iovt] = icol_split
                count += 1

def Analyze_header_line_QSoft(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms1 = ['F_1:1\t','F_1:3','F_1:5','F_1:7','F_1:9','F_1:11','F_1:13']
    SearchTerms2 = ['F_2:1\t','F_2:3','F_2:5','F_2:7','F_2:9','F_2:11','F_2:13']
    SearchTerms3 = ['F_3:1\t','F_3:3','F_3:5','F_3:7','F_3:9','F_3:11','F_3:13']
    SearchTerms4 = ['F_4:1\t','F_4:3','F_4:5','F_4:7','F_4:9','F_4:11','F_4:13']
    Do_Import = np.zeros(Cor.novt,dtype = int)
    count = 0
    i_cols = np.ones((Cor.novt),dtype = int)*np.nan
    for iovt in range(Cor.novt):
        if SearchTerms1[iovt] in line or SearchTerms2[iovt] in line or \
           SearchTerms3[iovt] in line or SearchTerms4[iovt] in line:
            Do_Import[iovt] = 1
            i_cols[iovt] = int(1 + 2 * count)
            count += 1
    i_cols = i_cols.astype(int)

def Analyze_header_line_QSoft_new(line):
    global Do_Import_new,i_cols_new,i_cols_time
    i_cols_new  = np.ones((4,Cor.novt),dtype = int)*np.nan
    i_cols_time = np.ones((4         ),dtype = int)*np.nan
    Do_Import_new = np.zeros((4,Cor.novt),dtype = int)
    n_tones = np.zeros((4),dtype = int)
    SearchTerms = np.array([['f1_1','f3_1','f5_1','f7_1','f9_1','f11_1','f13_1'],\
                            ['f1_2','f3_2','f5_2','f7_2','f9_2','f11_2','f13_2'],
                            ['f1_3','f3_3','f5_3','f7_3','f9_3','f11_3','f13_3'],
                            ['f1_4','f3_4','f5_4','f7_4','f9_4','f11_4','f13_4']])
    for ichan in range(4):
        for iovt in range(Cor.novt):
            if SearchTerms[ichan,iovt] in line: Do_Import_new[ichan,iovt] = 1
    n_tones = np.sum(Do_Import_new,axis = 1)
    count = 0 
    for ichan in range(4):
        if n_tones[ichan] > 0:
            i_cols_time[ichan] = count
            for iovt in range(Cor.novt):
                i_cols_new[ichan,iovt] = count + 1 + 2 * np.sum(Do_Import_new[ichan,:iovt])
            count += 2 * n_tones[ichan] + 1
    i_cols_new  = i_cols_new.astype(int)        
    i_cols_time = i_cols_time.astype(int)
    choice_str = ''
    for j in range(4): 
        if np.sum(Do_Import_new[j,:]) > 0: choice_str += str(j+1) + ' '
    if np.sum(Do_Import_new[Cor.i_channel,:]) == 0: 
        Cor.i_channel = tk.simpledialog.askinteger('','select channel (' + choice_str + ')') - 1

def Analyze_header_line_AWSensors(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['Delta_F/n_n=1_','Delta_F/n_n=3_',\
                   'Delta_F/n_n=5_','Delta_F/n_n=7_',\
                   'Delta_F/n_n=9_','Delta_F/n_n=11_','Delta_F/n_n=13_']
    count = 0
    i_cols = np.ones((Cor.novt),dtype = int)*np.nan
    for iovt in range(Cor.novt):
        if SearchTerms[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + count
            count += 1
    i_cols = i_cols.astype(int)       

def Import_from_QTZ_direct():
    import QTM_Import_QTZ as importQTZ
    global time_in,Dfbyn_in,DGbyn_in
    time_in, Dfbyn_in, DGbyn_in,PlotOvertones = importQTZ.Read(Cor.SourceFilePath)

def Import_from_QTZ_exported():
    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QTZ(lines[0])    
    time_in  = np.ones((len(lines)         ))*np.nan
    Dfbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0
    for il in range(1,len(lines)):
        cols = lines[il].split()
        Line_long_enough = len(cols) >= 2 * n_tones + 1
        if Line_long_enough:
            time_in[count] = float(cols[0])
            for iovt in range(Cor.novt):
                if Do_Import[iovt]: 
                    Dfbyn_in[count,iovt] = float(cols[i_cols[iovt]    ])/Cor.ns[iovt]
                    DGbyn_in[count,iovt] = float(cols[i_cols[iovt] + 1])/Cor.ns[iovt]
            count += 1
    time_in  = time_in[:count]
    Dfbyn_in = Dfbyn_in[:count]
    DGbyn_in = DGbyn_in[:count]

def Import_from_QCMI():
    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QCMI(lines[0])    
    time_in  = np.ones(len( lines)          )*np.nan
    Dfbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0
    for il in range(1,len(lines)):
        cols = lines[il].split()
        Line_long_enough = len(cols) >= 15 * n_tones + 1
        if Line_long_enough:
            time_in[count] = float(cols[0])
            for iovt in range(Cor.novt):
                if Do_Import[iovt]: 
                    Dfbyn_in[count,iovt] = float(cols[i_cols[iovt]  ])/Cor.ns[iovt]
                    DGbyn_in[count,iovt] = float(cols[i_cols[iovt]+1])/Cor.ns[iovt]/2.
        count += 1
    time_in  = time_in[:count]
    Dfbyn_in = Dfbyn_in[:count]
    DGbyn_in = DGbyn_in[:count]

def Import_from_QSoft():
    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QSoft(lines[0])    
    time_in  = np.ones( len(lines)          )*np.nan
    Dfbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0 
    for il in range(1,len(lines)):
        line = lines[il].replace(',','.')
        cols = line.split()
        Line_long_enough = len(cols) >= 2 * n_tones + 1
        if Line_long_enough: 
            time_in[count] = float(cols[0])
            for iovt in range(Cor.novt):
                if Do_Import[iovt]: 
                    Dfbyn_in[count,iovt] = float(cols[i_cols[iovt]    ])                    
                    DGbyn_in[count,iovt] = float(cols[i_cols[iovt] + 1]) * Cor.f_fund/2./1e6
            count += 1
    time_in  = time_in[ :count]
    Dfbyn_in = Dfbyn_in[:count]
    DGbyn_in = DGbyn_in[:count]

def Import_from_QSoft_new():
    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QSoft_new(lines[0])    
    time_in  = np.ones( len(lines)          )*np.nan
    Dfbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    count = 0
    for il in range(1,len(lines)):
        line = lines[il].replace(',','.')
        cols = line.split()
        if i_cols_time[Cor.i_channel] <= len(cols)-1:
            time_in[count] = float(cols[i_cols_time[Cor.i_channel]])
            for iovt in range(Cor.novt):
                if Do_Import_new[Cor.i_channel,iovt]: 
                    Dfbyn_in[count,iovt] = float(cols[i_cols_new[Cor.i_channel,iovt]    ])/Cor.ns[iovt]  
                    DGbyn_in[count,iovt] = float(cols[i_cols_new[Cor.i_channel,iovt] + 1])*Cor.f_fund/2./1e6
            count += 1
    time_in  = time_in[ :count]
    Dfbyn_in = Dfbyn_in[:count] - Dfbyn_in[0]
    DGbyn_in = DGbyn_in[:count] - DGbyn_in[0]

def Import_from_AWSensors():
    Header1 = ['Delta_F/n_n=1_(Hz)','Delta_F/n_n=3_(Hz)',\
                'Delta_F/n_n=5_(Hz)','Delta_F/n_n=7_(Hz)',\
                'Delta_F/n_n=9_(Hz)','Delta_F/n_n=11_(Hz)','Delta_F/n_n=13_(Hz)']
    Header2 = ['Delta_D_n=1_()','Delta_D_n=3_()','Delta_D_n=5_()','Delta_D_n=7_()',\
                'Delta_D_n=9_()','Delta_D_n=11_()','Delta_D_n=13_()']
    Header3 = ['Delta_Gamma/n_n=1_(Hz)','Delta_Gamma/n_n=3_(Hz)','Delta_Gamma/n_n=5_(Hz)',\
                'Delta_Gamma/n_n=7_(Hz)','Delta_Gamma/n_n=9_(Hz)','Delta_Gamma/n_n=11_(Hz)',\
                'Delta_Gamma/n_n=13_(Hz)']
    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    #This remoRheos the % header in some of the AWsensors exported files, but doesn't touch the files that don't haRheo such a header 
    lindex=0
    while lines[lindex][0]=='%':
        lines.pop(lindex)
    if len(lines)<2:
        tk.messagebox.showinfo('','The file is corrupt. Try re-exporting the data from AWSensors software again.')
        return
        
    #ConRheorting lines into dataframe using the 0th line as the header
    header=lines[0].split('\t')
    df = pd.DataFrame([sub.split('\t') for sub in header]).transpose()
    lines.pop(0)
    df = pd.DataFrame([sub.split('\t') for sub in lines], columns=header)
    
    #Initializing your arrays
    length=len(df)
    time_in  = np.ones( length          )*np.nan
    Dfbyn_in = np.ones((length,Cor.novt))*np.nan
    DGbyn_in = np.ones((length,Cor.novt))*np.nan

    #looking for the first occurrance of the time axis (depending on the typle of file, there may be more than one)
    #this should be easy to expand to other axes, like current, electrochemistry, but let's leaRheo this for now
    df1=df.filter(like='Time')
    if not df1.empty:
        time_in=df1.iloc[:,0].to_numpy(dtype=np.float64)
    else:
        #If no time data is found, return an error
        tk.messagebox.showinfo('','File format error: cannot find the time data. Try re-exporting the data from AWSensors software again.')
        return

    #These are frequencies, they are always the same in all the exported files
    df1=df.filter(Header1)
    if not df1.empty:
        for i in range(0,7):
            df1=df.filter(like=Header1[i])
            if not df1.empty:
                Dfbyn_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
    else:
        #If no frequencies found, return an error
        tk.messagebox.showinfo('','File format error: cannot find the frequency data. Try re-exporting the data from AWSensors software again.')
        return

    #Looking for dissipations
    df1 = df.filter(Header2)
    if not df1.empty:
        for i in range(0,7):
            df1=df.filter(like=Header2[i])
            if not df1.empty:
                DGbyn_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
                DGbyn_in[:,i]=DGbyn_in[:,i]*Cor.f_fund/2
    else:
        #if no dissipations are found, looking for bandwidths...
        df1 = df.filter(Header3)
        if not df1.empty:
            for i in range(0,7):
                df1=df.filter(like=Header3[i])
                if not df1.empty:
                    DGbyn_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
        else:
            #if neither dissipations nor bandwidths are found, we haRheo a problem.
            tk.messagebox.showinfo('','File format error: cannot find either the dissipation or the bandwidth data. Try re-exporting the data from AWSensors software again.')
            return
    del df, df1

def Import_from_OpenQCM():
    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_OpenQCM(lines[0])    
    time_in  = np.ones(len( lines)          )*np.nan
    Dfbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    count = 0
    for il in range(1,len(lines)):
        cols = lines[il].split(',')
        time_in[count] = float(cols[2])  # time in column 3
        novt_loc = int((len(cols)-4)/2)
        for iovt in range(novt_loc):
            if Do_Import[iovt]: 
                cols[i_cols[iovt]].replace('\n','')
                Dfbyn_in[count,iovt] = float(cols[i_cols[iovt]  ])/Cor.ns[iovt]
                DGbyn_in[count,iovt] = float(cols[i_cols[iovt]+1])/Cor.ns[iovt] * Cor.f_fund/2.
        count += 1
    time_in  = time_in[ :count]
    Dfbyn_in = Dfbyn_in[:count]
    DGbyn_in = DGbyn_in[:count]
    
def Import_from_3T_analytik():
    # kindly supplied by Adam Olsson
    Header1 = ['f1-f1_ref [Hz]','f3-f3_ref [Hz]','f5-f5_ref [Hz]','f7-f7_ref [Hz]','f9-f9_ref [Hz]']
    Header2 = ['Delta_D_n=1_()','Delta_D_n=3_()','Delta_D_n=5_()','Delta_D_n=7_()',\
                'Delta_D_n=9_()','Delta_D_n=11_()','Delta_D_n=13_()']
    Header3 = ['G1-G1_ref [Hz]','G3-G3_ref [Hz]','G5-G5_ref [Hz]','G7-G7_ref [Hz]','G9-G9_ref [Hz]']

    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    #This remoRheos the Ref headers and footer of the 3T analytik exported files. 
    lindex=0
    lines.pop(lindex)
    lines.pop(lindex)
    lindex=1
    lines.pop(lindex)
    i=0
    while i < 3: 
        lindex=-1
        lines.pop(lindex)
        i+=1
    #ConRheorting lines into dataframe using the 0th line as the header
    header=lines[0].split("\t")
    col=lines[1].split("\t")
    df=pd.DataFrame([col],columns=header)
    for index in range(2,len(lines)):
        col=lines[index].split("\t")
        df.loc[len(df)] = col

    #Initializing arrays
    length=len(df)
    time_in  = np.ones( length          )*np.nan
    Dfbyn_in = np.ones((length,Cor.novt))*np.nan
    DGbyn_in = np.ones((length,Cor.novt))*np.nan

    #looking for the first occurrance of the time axis (depending on the typle of file, there may be more than one)
    #this should be easy to expand to other axes, like current, electrochemistry, but let's leaRheo this for now
    df1=df.filter(like='time')
    if not df1.empty:
        time_in=df1.iloc[:,0].to_numpy(dtype=np.float64)
    else:
        tk.messagebox.showinfo('','File format error: cannot find the time data. Try re-exporting the data from 3T analytik qGraphViewer again.')
        return

    #These are frequencies, they are always the same in all the exported files
    df1=df.filter(Header1)
    if not df1.empty:
        for i in range(0,5):
            df1=df.filter(like=Header1[i])
            if not df1.empty:
                Dfbyn_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
    else:
        tk.messagebox.showinfo('','File format error: cannot find the frequency data. Try re-exporting the data from 3T analytik qGraphViewer again.')
        return

    #Looking for dissipations
    df1 = df.filter(Header2)
    if not df1.empty:
        for i in range(0,7):
            df1=df.filter(like=Header2[i])
            if not df1.empty:
                DGbyn_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
                DGbyn_in[:,i]=DGbyn_in[:,i]*Cor.f_fund/2
    else:
        #if no dissipations are found, looking for bandwidths...
        df1 = df.filter(Header3)
        if not df1.empty:
            for i in range(0,5):
                df1=df.filter(like=Header3[i])
                if not df1.empty:
                    DGbyn_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
        else:
            tk.messagebox.showinfo('','File format error: cannot find either the dissipation or the bandwidth data. Try re-exporting the data from 3T analytik qGraphViewer again.')
            return

def Import_from_PyQTZ():
    global time_in,Dfbyn_in,DGbyn_in
    f = open(Cor.SourceFilePath,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_PyQTZ(lines[0])    
    time_in  = np.ones(len( lines)          )*np.nan
    Dfbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_in = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0
    for il in range(1,len(lines)):
        cols = lines[il].split()
        Line_long_enough = len(cols) >= 2 * n_tones + 1
        if Line_long_enough:
            time_in[count] = float(cols[1])
            for iovt in range(Cor.novt):
                if Do_Import[iovt]: 
                    Dfbyn_in[count,iovt] = float(cols[i_cols[iovt]    ])
                    DGbyn_in[count,iovt] = float(cols[i_cols[iovt] + 2*np.sum(Do_Import)])
            count += 1
    time_in  = time_in[:count]
    Dfbyn_in = Dfbyn_in[:count]
    DGbyn_in = DGbyn_in[:count]

def Calc_PreAverages():
    global time_avgd,Dfbyn_avgd,DGbyn_avgd
    first = True
    if Cor.n_pre_avg > 1 : 
        icount = 0
        while icount < len(time_in)//Cor.n_pre_avg:
            icenter  = int((icount + 0.5)*Cor.n_pre_avg)
            sumDfbyn = np.zeros(Cor.novt)
            sumDGbyn = np.zeros(Cor.novt)
            norm = 0
            for i in range(np.max([0             ,int((icount - 1)*Cor.n_pre_avg)]),\
                           np.min([len(time_in)-1,int((icount + 1)*Cor.n_pre_avg)])):
                weight = np.exp(-(i-icenter)**2/(2.*(Cor.n_pre_avg/2.)**2))
                norm += weight
                for iovt in range(Cor.novt):
                    sumDfbyn[iovt] += Dfbyn_in[i,iovt] * weight
                    sumDGbyn[iovt] += DGbyn_in[i,iovt] * weight
            if norm > 0 : 
                for iovt in range(Cor.novt):
                    sumDfbyn[iovt] /= norm
                    sumDGbyn[iovt] /= norm
            else :     
                for iovt in range(Cor.novt):
                    sumDfbyn[iovt] = np.nan
                    sumDGbyn[iovt] = np.nan
            if first: 
                time_avgd = time_in[icenter]
                Dfbyn_avgd = [sumDfbyn]
                DGbyn_avgd = [sumDGbyn]
                first = False
            else :     
                time_avgd  = np.append(time_avgd ,time_in[icenter])    
                Dfbyn_avgd = np.append(Dfbyn_avgd,[sumDfbyn],axis = 0)    
                DGbyn_avgd = np.append(DGbyn_avgd,[sumDGbyn],axis = 0)
            icount += 1
    else : 
        time_avgd  = time_in
        Dfbyn_avgd = Dfbyn_in
        DGbyn_avgd = DGbyn_in

def Import_Shifts():
    global Shifts,FPars
    shutil.copyfile(Cor.SourceFilePath,os.getcwd()+'/tmp/' + os.path.basename(Cor.SourceFilePath))
    if Cor.ImportFormat == 'from QTZ (.qtz)'  : Import_from_QTZ_direct()
    if Cor.ImportFormat == 'from QTZ exported': Import_from_QTZ_exported()
    if Cor.ImportFormat == 'from QSoft'       : Import_from_QSoft()
    if Cor.ImportFormat == 'from QSoft new'   : Import_from_QSoft_new()
    if Cor.ImportFormat == 'from AWSensors'   : Import_from_AWSensors()
    if Cor.ImportFormat == 'from OpenQCM'     : Import_from_OpenQCM()
    if Cor.ImportFormat == 'from QCM-I'       : Import_from_QCMI()
    if Cor.ImportFormat == 'from 3TAnalytik'  : Import_from_3T_analytik()
    if Cor.ImportFormat == 'from PyQTZ'       : Import_from_PyQTZ()
    Calc_PreAverages()
    Shifts = np.ones((len(Dfbyn_avgd),2+4*Cor.novt))*np.nan
    for it in range(len(Dfbyn_avgd)):
        Shifts[it,0]=it
        Shifts[it,1]=time_avgd[it]
        for iovt in range(Cor.novt):
            Shifts[it,2+4*iovt  ] = Dfbyn_avgd[it,iovt]
            Shifts[it,2+4*iovt+1] = DGbyn_avgd[it,iovt]
    Cor.i_selec    = 0
    Cor.i_start_fit = 0
    Cor.i_stop_fit = len(Shifts)
    Cor.i_start_hide_Shifts = 0; Cor.i_stop_hide_Shifts = 0 
    Cor.i_start_zoom_Shifts = 0; Cor.i_stop_zoom_Shifts = len(Shifts);   
    Cor.i_start_zoom_FP = 0; Cor.i_stop_zoom_FP = len(FPars); 
    for iovt in range(Cor.novt):
        Cor.Dfbyns[iovt] = Shifts[Cor.i_selec,2+4*iovt  ]
        Cor.DGbyns[iovt] = Shifts[Cor.i_selec,2+4*iovt+1]
    Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
    Cor.Fit_done = 'no'
    Calc_rms_noise_Dfbyn()
    if Cor.Correct_Drift == 'yes': Shifts = Correct_for_Drift(Shifts)
    Make_headers()
    np.savetxt(os.getcwd() + '/tmp/Shifts.qtm'           ,Shifts,header = header_Shifts,delimiter='\t',newline = '\n')
    np.savetxt(os.getcwd() + '/tmp/Shifts_for_unhide.qtm',Shifts,header = header_Shifts,delimiter='\t',newline = '\n')
    
    FPars = np.ones((len(Shifts),17))*np.nan
    np.savetxt(os.getcwd() + '/tmp/FPars.qtm',FPars,header = header_FPars,delimiter='\t',newline = '\n')
    Cor.i_start_hide_Shifts = 0; Cor.FP_i_start_hide_Shifts = 0
    Cor.i_stop_hide_Shifts = 0; Cor.FP_i_stop_hide_Shifts = 0
    for iovt in range(Cor.novt): Cor.OvtInc[iovt] = 1
    Cor.Write_Config()

def Correct_for_Drift(Shifts):
    Shifts_DriftCorr = np.ones((len(Shifts),2+4*Cor.novt))*np.nan
    Shifts_DriftCorr[:,0] = Shifts[:,0]
    Shifts_DriftCorr[:,1] = Shifts[:,1]
    n_pre_avg_loc = max(Cor.n_pre_avg,1)
    for it in range(len(Shifts)-1):
        count = 0
        for iovt in range(Cor.novt):
            if not np.isnan(Shifts[it,2+4*iovt  ]) and not np.isnan(Shifts[it+1,2+4*iovt  ]):  
                Shifts_DriftCorr[it  ,2+4*iovt] = Shifts[it,2+4*iovt  ]-count/len(Cor.ns_inc)/n_pre_avg_loc*\
                     (Shifts[it+1,2+4*iovt]-Shifts[it,2+4*iovt])
                count += 1
        count = 0
        for iovt in range(Cor.novt):
            if not np.isnan(Shifts[it,2+4*iovt+1]) and not np.isnan(Shifts[it+1,2+4*iovt+1]):  
                Shifts_DriftCorr[it  ,2+4*iovt+1] = Shifts[it,2+4*iovt+1]-count/len(Cor.ns_inc)/n_pre_avg_loc*\
                     (Shifts[it+1,2+4*iovt+1]-Shifts[it,2+4*iovt+1])
                count += 1         
    Shifts = Shifts_DriftCorr
    return Shifts

def Calc_rms_noise_Dfbyn():
    Hadamards = np.ones((Cor.novt,len(Shifts)))*np.nan
    timesteps = np.ones((Cor.novt,len(Shifts)))*np.nan
    if Cor.i_stop_fit > len(Shifts) : Cor.i_stop_fit = len(Shifts)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            for it in range(Cor.i_start_fit+1,Cor.i_stop_fit-1):
                Hadamards[iovt,it-1] = \
                 1./6. *(Shifts[it-1,2+4*iovt  ] - 2.* Shifts[it,2+4*iovt  ] + Shifts[it+1,2+4*iovt  ])**2
                timesteps[iovt,it-1] = Shifts[it,1] - Shifts[it-1,1]
    onlyNans = True
    for iovt in range(Cor.novt):
        for i in range(len(Hadamards[0])):
            if not np.isnan(Hadamards[iovt,i]): 
                onlyNans = False
    if not onlyNans: 
        Cor.rms_noise_Dfbyn = np.nanmean(Hadamards)**0.5
        timestep_mean = np.nanmean(timesteps)
        Cor.rms_noise_Dfbyn_bySqrtHz = Cor.rms_noise_Dfbyn * timestep_mean**0.5
        if Cor.TimeUnit == 'ms'   : Cor.rms_noise_Dfbyn_bySqrtHz /= 1000.**0.5
        if Cor.TimeUnit == 'min'  : Cor.rms_noise_Dfbyn_bySqrtHz /= (1./60)**0.5
        if Cor.TimeUnit == 'hour' : Cor.rms_noise_Dfbyn_bySqrtHz /= (1./3600.)**0.5
    else : 
        Cor.rms_noise_Dfbyn = np.nan     
        Cor.rms_noise_Dfbyn_bySqrtHz = np.nan
    Cor.Write_Config()
            
def Make_headers():
    global header_Shifts,header_FPars,header_Jppometas
    Get_Labels()
    header_Shifts = 'data_point \t time[a.u.] \t'
    for iovt in range(Cor.novt):
        header_Shifts += 'Dfbyn_'    + str(Cor.ns[iovt]) + '\t' + 'DGbyn_'    + str(Cor.ns[iovt]) + '\t' + \
                           'Dfbyn_fit_'+ str(Cor.ns[iovt]) + '\t' + 'DGbyn_fit_'+ str(Cor.ns[iovt]) + '\t'
    header_Shifts = header_Shifts[:-1]                       
    header_FPars = 'data_point \t time[a.u.] \t'
    for Key in Cor.ModelParKeys: 
        header_FPars += header_Labels_Model[Key] + '\t' + header_Labels_Model[Key] + '_StdErr \t'
    for Key in Cor.RheoParKeys: 
        header_FPars += header_Labels_Rheo[Key] + '\t'
    header_FPars     += 'chi^2'
    header_Jppometas = 'data_point \t time[a.u.] \t'
    for iovt in range(Cor.novt):
        header_Jppometas += 'Jppometas_'    + str(Cor.ns[iovt]) + '\t'
    header_Jppometas = header_Jppometas[:-1]                       
    
def Initialize():
    global Shifts,FPars
    Cor.CurrWD = os.getcwd()
    Make_headers()
    if os.path.isfile(os.getcwd()+'/tmp/Shifts.qtm'): 
        Shifts = np.loadtxt(os.getcwd()+'/tmp/Shifts.qtm',skiprows=1)
    else : Shifts = np.ones((1,2+4*Cor.novt))*np.nan
    if os.path.isfile(os.getcwd()+'/tmp/FPars.qtm'): 
        FPars    = np.loadtxt(os.getcwd()+'/tmp/FPars.qtm',skiprows=1)
    else : FPars = np.ones((len(Shifts),17))*np.nan
    Calc_rms_noise_Dfbyn();
