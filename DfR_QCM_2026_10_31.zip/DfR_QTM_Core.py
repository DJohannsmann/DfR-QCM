import numpy as np
import configparser
import DfR_QTM_IO as IO
from scipy.stats import linregress
from scipy.optimize import curve_fit
import os

def Get_Labels(): 
    global RheoParKeys,ModelParKeys,SetParKeys,SetParLabels,OvtIncLabels,DfbynLabels,DGbynLabels,\
        RheoLabels_re,RheoLabels_im,RheoLabels_both,RheoTypes,iRheoTypes,\
        DfRatLabels,DfRatTypes,iDfRatTypes,RefLabels,RefTypes,iRefTypes,\
        stat_weight_strings,TimeUnit_strings,iTimeUnit_strings,ImportFormats,iImportFormats,\
        Start_from_strings,DD_DGbyn_strings,vs_time_datapoint_strings,Colors,ready_state,Abort
    RheoParKeys  = ['Par1','Par2','PLExp1','PLExp2']
    ModelParKeys = ['t','Par1','Par2','PLExp1','PLExp2']
    SetParKeys   = ['rho','rhoBulk','etaBulk']

    RheoLabels_re = ['J\' [MPa\u207B\u00B9]','G\' [MPa]','\u03B7\' [mPa s]',\
                     'G\' [MPa]','|J| [MPa\u207B\u00B9]','|G| [MPa]','|\u03B7| [mPa s]']
    RheoLabels_im = ['J\'\' [MPa\u207B\u00B9]','G\'\' [MPa]','\u03B7\'\' [mPa s]',\
                     '\u03B7\' [mPa s]','tan(\u03B4)','tan(\u03B4)','tan(\u03B4)']    
    RheoLabels_both = ['J\',J\'\'','G\',G\'\'','\u03B7\',\u03B7\'\'','G\',\u03B7\'',\
                         '|J|,tan(\u03B4)','|G|,tan(\u03B4)','|\u03B7|,tan(\u03B4)']
    RheoTypes    = ['Jp_Jpp','Gp_Gpp','etap_etapp','Gp_etap','|J|_tandel','|G|_tandel','|eta|_tandel']
    iRheoTypes   = dict(zip(RheoTypes,list(range(len(RheoTypes)))))   
    
    DfRatLabels  = ['DfR \u2192 J\',\u03B2\'','DfR \u2192 J\'','DfR \u2192 \u03B2\'','DfR \u2192 none',]
    DfRatTypes   = ['Jp_betap','Jp','betap','none']
    iDfRatTypes  = dict(zip(DfRatTypes,list(range(len(DfRatTypes)))))   

    RefLabels  = ['Ref: Bare Qrtz','Ref: Bulk Liq']
    RefTypes   = ['BareQuartz','BulkLiquid']
    iRefTypes  = dict(zip(RefTypes,list(range(len(RefTypes)))))   



    SetParLabels = ['Density [g/cm^3]''Density Bulk [g/cm^3]','Viscosity Bulk [mPa s]']
 
    OvtIncLabels = ['OvtInc1','OvtInc2','OvtInc3','OvtInc4','OvtInc5','OvtInc6','OvtInc7'] 
    DfbynLabels  = ['Dfbyn1','Dfbyn2','Dfbyn3','Dfbyn4','Dfbyn5','Dfbyn6','Dfbyn7']
    DGbynLabels  = ['DGbyn1','DGbyn2','DGbyn3','DGbyn4','DGbyn5','DGbyn6','DGbyn7']
    stat_weight_strings = ['n^-1','n^-(0.5)','flat','n^(0.5)','n^1']
    TimeUnit_strings = ['ms','sec','min','hour']
    iTimeUnit_strings = dict(zip(TimeUnit_strings,list(range(len(TimeUnit_strings)))))   
    ImportFormats = ['from QTZ (.qtz)','from QTZ exported','from QSoft','from QSoft new','from AWSensors',\
            'from OpenQCM','from QCM-I','from 3TAnalytik','from PyQTZ']
    iImportFormats   = dict(zip(ImportFormats,list(range(len(ImportFormats)))))   
    Start_from_strings = ['Start_from_Default','Start_from_Previous']
    DD_DGbyn_strings   = ['DGbyn','DD']
    vs_time_datapoint_strings = ['time','datapoint']
    Colors = ['k','r','lime','b','fuchsia','gray','purple']

def Write_Ini(): 
    configIni['Main']={}
    configIni['Main']['Start_from'] = Start_from
    for i in range(n_previous): 
        PreviousFilePaths.append('')
        configIni['Main']['PreviousFilePaths_'+str(i)] = PreviousFilePaths[i].replace('%','%%')
        PreviousSourcePaths.append('')
        configIni['Main']['PreviousSourcePaths_'+str(i)] = PreviousSourcePaths[i].replace('%','%%')
        PreviousSourceFormats.append('')
        configIni['Main']['PreviousSourceFormats_'+str(i)] = PreviousSourceFormats[i]
    with open('QTM.ini','w') as configInifile: configIni.write(configInifile)

def Read_Ini():
    global configIni,PreviousFilePaths,PreviousSourcePaths,PreviousSourceFormats,Start_from,n_previous
    n_previous = 10
    PreviousFilePaths = []
    PreviousSourcePaths = []
    PreviousSourceFormats = []
    for i in range(n_previous): 
        PreviousFilePaths.append('')
        PreviousSourcePaths.append('')
        PreviousSourceFormats.append('')
    configIni = configparser.ConfigParser()
    if os.path.isfile('QTM.ini') :     
        configIni.read('QTM.ini')
        Start_from   = configIni.get('Main','Start_from',fallback='Start_from_Default')
        for i in range(n_previous):
            PreviousFilePaths[i]     = configIni.get('Main','PreviousFilePaths_'+str(i),fallback='')
            PreviousSourcePaths[i]   = configIni.get('Main','PreviousSourcePaths_'+str(i),fallback='')
            PreviousSourceFormats[i] = configIni.get('Main','PreviousSourceFormats_'+str(i),fallback='')
    else :
        Start_from = 'Start_from_Default'
        for i in range(n_previous): PreviousFilePaths[i] = ''
    
def Write_Config(): 
    IO.Get_Labels()
    config['Main']       = {}
    config['ModelPars']      = {}
    config['ModelParStdErrs']= {}
    config['RheoPars']       = {}
    config['SetPars']        = {}
    config['IncInFits']      = {}
    config['DfDGbyn']        = {}
    config['Main']['stat_weight']       = stat_weight
    config['Main']['TimeUnit']          = TimeUnit
    config['Main']['DD_DGbyn']          = DD_DGbyn
    config['Main']['FitDone']           = FitDone
    config['Main']['SourceFilePath']    = SourceFilePath.replace('%','%%')
    config['Main']['ConfigFilePath']    = ConfigFilePath.replace('%','%%')
    config['Main']['ImportFormat']      = ImportFormat
    config['Main']['Correct_Drift']     = Correct_Drift
    config['Main']['InfoString']        = InfoString
    config['Main']['vs_time_datapoint'] = vs_time_datapoint
    config['Main']['RheoType']          = RheoType
    config['Main']['DfRatType']         = DfRatType
    config['Main']['RefType']           = RefType
    config['Main']['f_fund']            = str(f_fund)
    config['Main']['Z_q']               = str(Zq)
    config['Main']['f_cen']             = str(f_cen)
    config['Main']['ErrDfbyn']          = str(ErrDfbyn)
    config['Main']['rms_noise_Dfbyn']   = str(rms_noise_Dfbyn)
    config['Main']['rms_noise_Dfbyn_bySqrtHz'] = str(rms_noise_Dfbyn_bySqrtHz)
    config['Main']['RelWeight_DfDG']    = str(RelWeight_DfDG)
    config['Main']['n_pre_avg']         = str(n_pre_avg)
    config['Main']['i_start_fit']       = str(i_start_fit)
    config['Main']['i_stop_fit']        = str(i_stop_fit)
    config['Main']['i_selec']           = str(i_selec)
    config['Main']['i_channel']         = str(i_channel)
    config['Main']['Update_Inval']      = str(Update_Inval)
    config['Main']['n_RndNoise'     ]   = str(n_RndNoise)
    config['Main']['i_RN_Par1'      ]   = str(i_RN_Par1)
    config['Main']['i_RN_Par2'      ]   = str(i_RN_Par2)
    
    
    config['Main']['i_start_hide_Shifts']= str(i_start_hide_Shifts)
    config['Main']['i_stop_hide_Shifts'] = str(i_stop_hide_Shifts)
    config['Main']['i_start_avrg']       = str(i_start_avrg)
    config['Main']['i_stop_avrg' ]       = str(i_stop_avrg)
    config['Main']['i_start_zoom_Shifts']= str(i_start_zoom_Shifts)
    config['Main']['i_stop_zoom_Shifts'] = str(i_stop_zoom_Shifts)
    config['Main']['i_start_hide_FP']    = str(i_start_hide_FP)
    config['Main']['i_stop_hide_FP']     = str(i_stop_hide_FP)
    config['Main']['i_start_zoom_FP']    = str(i_start_zoom_FP)
    config['Main']['i_stop_zoom_FP']     = str(i_stop_zoom_FP)
    config['Main']['i_PlotErrBars']      = str(i_PlotErrBars)

    config['Main']['chi2LS_min']        = str(chi2LS_min) 
    config['Main']['chi2LS_max']        = str(chi2LS_max) 
    config['Main']['chi2LS_Fac']        = str(chi2LS_Fac) 
    config['Main']['chi2LS_n']          = str(chi2LS_n) 
    config['Main']['chi2LS_i_Par_Varied']=str(chi2LS_i_Par_Varied)

    config['Main']['WindowHeight']      = str(WindowHeight)
    config['Main']['WindowWidth']       = str(WindowWidth)
    config['Main']['WindowTop']         = str(WindowTop)
    config['Main']['WindowLeft']        = str(WindowLeft)

    for Key in ModelParKeys:
        config['IncInFits'       ][Key] = str(IncInFits[Key])
        config['ModelPars'      ][Key] = str(ModelPars[Key])
        config['ModelParStdErrs'][Key] = str(ModelParStdErrs[Key])
    for Key in RheoParKeys:
        config['RheoPars'       ][Key] = str(RheoPars[Key])
    for Key in SetParKeys:
        config['SetPars'        ][Key] = str(SetPars[Key])
    for iovt in range(novt):    
        config['DfDGbyn'][OvtIncLabels[iovt]] = str(int(OvtInc[iovt]))
        config['DfDGbyn'][DfbynLabels[ iovt]] = str(    Dfbyns[iovt] )
        config['DfDGbyn'][DGbynLabels[ iovt]] = str(    DGbyns[iovt] )
    if FitDone == 'no': 
        config.remove_section('RheoParStdErrs')
    os.makedirs(os.getcwd() + '/tmp', exist_ok=True)
    with open(os.getcwd()+'/tmp/Config.qtm','w') as configfile: config.write(configfile)

def Read_Config():
    global ModelPars,ModelPars_old,ModelParStdErrs,RheoPars,SetPars,\
        BoundsMin,BoundsMax,Adjusted_to_Bounds,IncInFits,OvtInc,Dfbyns,DGbyns,Dfcbyns,Dfcbyns_Model,\
        stat_weight,TimeUnit,RelWeight_DfDG,FitDone,nFPars,Ovt_Labels,\
        DD_DGbyn,InfoString,f_fund,f_cen,Zq,RheoType,DfRatType,RefType,\
        ErrDfbyn,Update_Inval,rms_noise_Dfbyn,rms_noise_Dfbyn_bySqrtHz,Abort_Enabled,Abort,\
        vs_time_datapoint,SourceFilePath,ConfigFilePath,SourceFilePathstr,ImportFormat,Correct_Drift,\
        n_pre_avg,i_channel,i_ready,i_selec,i_start_fit,i_stop_fit,i_current,i_new_zero,\
        i_start_hide_Shifts,i_stop_hide_Shifts,i_start_hide_FP,i_stop_hide_FP,\
        i_start_zoom_Shifts,i_stop_zoom_Shifts,i_start_zoom_FP,i_stop_zoom_FP,i_PlotErrBars,\
        i_start_avrg,i_stop_avrg,i_col_x,n_RndNoise,i_RN_Par1,i_RN_Par2,\
        novt,nFParsmax,ns,\
        chi2LS_min,chi2LS_max,chi2LS_Fac,chi2LS_n,chi2LS_i_Par_Varied,\
        WindowHeight,WindowWidth,WindowTop,WindowLeft,config,ready_state
        
    Abort_Enabled = False; Abort = False; novt = 7; nFParsmax = 5;
    ns = np.array([1,3,5,7,9,11,13])
    config = configparser.ConfigParser()
    # configIni.optionxform = lambda option: option
    if os.path.isfile(os.getcwd()+'/tmp/Config.qtm'): config.read(os.getcwd()+'/tmp/Config.qtm')
    else : config.read('Defaults.qtm')
    BoundsMin = {}; BoundsMax={};
    BoundsMin['t'] = 0  ; BoundsMin['Par1'] = 1e-7; BoundsMin['Par2'] = 1e-7; 
    BoundsMax['t'] = 1e4; BoundsMax['Par1'] = 1e7;  BoundsMax['Par2'] = 1e7;  
    BoundsMin['PLExp1'] = -2; BoundsMin['PLExp2'] = -1;
    BoundsMax['PLExp1'] =  0; BoundsMax['PLExp2'] =  1;
    IncInFits={}; ModelPars={}; RheoPars={}; ModelPars_old={}; ModelParStdErrs={}; SetPars={}
    nFPars = 0
    for Key in ModelParKeys:
        ModelPars[      Key] = np.float64(config.get('ModelPars'      ,Key,fallback=1))
        ModelPars_old[  Key] = np.float64(config.get('ModelPars_old'  ,Key,fallback=1))
        ModelParStdErrs[Key] = np.float64(config.get('ModelParStdErrs',Key,fallback=0))
        IncInFits[      Key] = int(config.get('IncInFits'             ,Key,fallback=0))
        if IncInFits[Key] == 1 : nFPars += 1
    for Key in RheoParKeys:
        RheoPars[Key] = np.float64(config.get('RheoPars',Key,fallback=1))
    for Key in SetParKeys:
        SetPars[Key] = np.float64(config.get('SetPars',Key,fallback=1))
        
    OvtInc = np.ones(novt,dtype = int)*np.nan
    Dfbyns = np.zeros(novt)
    DGbyns = np.zeros(novt)
    for i in range(novt):    
        OvtInc[i] = int(np.float64(config.get('DfDGbyn',OvtIncLabels[i],fallback=1)))
        Dfbyns[i] =     np.float64(config.get('DfDGbyn',DfbynLabels[i] ,fallback=0))
        DGbyns[i] =     np.float64(config.get('DfDGbyn',DGbynLabels[i] ,fallback=0))
    Dfcbyns = Dfbyns + 1j * DGbyns 

    stat_weight       = config.get('Main','stat_weight'      ,fallback='flat')
    TimeUnit          = config.get('Main','TimeUnit'         ,fallback='sec')
    DD_DGbyn          = config.get('Main','DD_DGbyn'         ,fallback='DGbyn')
    FitDone           = config.get('Main','FitDone'          ,fallback='no')
    SourceFilePath    = config.get('Main','SourceFilePath'   ,fallback='')
    SourceFilePathstr = os.path.basename(SourceFilePath)[:25  ]
    if len(os.path.basename(SourceFilePath)) > 25 :
        SourceFilePathstr += '\n' + os.path.basename(SourceFilePath)[25:50]  
    if len(os.path.basename(SourceFilePath)) > 50 :
        SourceFilePathstr += '\n' + os.path.basename(SourceFilePath)[50:75]  
    print(SourceFilePath,SourceFilePathstr)    

    ConfigFilePath    = config.get('Main','ConfigFilePath'   ,fallback='')
    ImportFormat      = config.get('Main','ImportFormat'     ,fallback='from QTZ (.qtz)')
    Correct_Drift     = config.get('Main','Correct_Drift'    ,fallback='no')
    InfoString        = config.get('Main','InfoString'       ,fallback='') 
    vs_time_datapoint = config.get('Main','vs_time_datapoint',fallback='time')
    RheoType          = config.get('Main','RheoType'         ,fallback='Jp_Jpp')  
    DfRatType         = config.get('Main','DfRatType'        ,fallback='Jp')
    RefType           = config.get('Main','RefType'          ,fallback='BulkLiquid')

    RelWeight_DfDG    = np.float64(config.get('Main','RelWeight_DfDG',fallback=1))
    chi2LS_min        = np.float64(config.get('Main','chi2LS_min'         ,fallback=0))
    chi2LS_max        = np.float64(config.get('Main','chi2LS_max'         ,fallback=100))
    chi2LS_Fac        = np.float64(config.get('Main','chi2LS_Fac'         ,fallback=5))
    chi2LS_n          = int(config.get('Main','chi2LS_n'                  ,fallback=100))
    chi2LS_i_Par_Varied=int(config.get('Main','chi2LS_i_Par_Varied'       ,fallback=0))

    f_fund            = np.float64(config.get('Main','f_fund',fallback=5e6))
    f_cen             = np.float64(config.get('Main','f_cen' ,fallback=30e6))
    Zq                = np.float64(config.get('Main','Z_q'   ,fallback=8.8e6)) 
    Ovt_Labels = []
    for iovt in range(novt):
        Ovt_Labels = np.append(Ovt_Labels,str(ns[iovt]*int(f_fund/1e6))+' MHz')
    ErrDfbyn          = np.float64(config.get('Main','ErrDfbyn'       ,fallback=0.1))
    rms_noise_Dfbyn   = np.float64(config.get('Main','rms_noise_Dfbyn',fallback=np.nan))
    rms_noise_Dfbyn_bySqrtHz = np.float64(config.get('Main','rms_noise_Dfbyn_bySqrtHz' ,fallback=np.nan))
    
    n_RndNoise         = int(config.get('Main','n_RndNoise'    ,fallback=100))
    i_RN_Par1          = int(config.get('Main','i_RN_Par1'     ,fallback=0))
    i_RN_Par2          = int(config.get('Main','i_RN_Par2'     ,fallback=1))
    n_pre_avg          = int(config.get('Main','n_pre_avg'     ,fallback=1))
    i_start_fit        = int(config.get('Main','i_start_fit'    ,fallback=0))
    i_stop_fit         = int(config.get('Main','i_stop_fit'    ,fallback=0))
    i_start_hide_Shifts= int(config.get('Main','i_start_hide_Shifts',fallback=0))
    i_stop_hide_Shifts = int(config.get('Main','i_stop_hide_Shifts',fallback=0))
    i_start_avrg       = int(config.get('Main','i_start_avrg'   ,fallback=0))
    i_stop_avrg        = int(config.get('Main','i_stop_avrg'   ,fallback=0))
    i_start_zoom_Shifts= int(config.get('Main','i_start_zoom_Shifts',fallback=0))
    i_stop_zoom_Shifts = int(config.get('Main','i_stop_zoom_Shifts',fallback=0))
    i_start_hide_FP    = int(config.get('Main','i_start_hide_FP',fallback=0))
    i_stop_hide_FP     = int(config.get('Main','i_stop_hide_FP',fallback=0))
    i_start_zoom_FP    = int(config.get('Main','i_start_zoom_FP',fallback=0))
    i_stop_zoom_FP     = int(config.get('Main','i_stop_zoom_FP',fallback=0))
    i_selec            = int(config.get('Main','i_selec'       ,fallback=0))
    i_current          = int(config.get('Main','i_current'     ,fallback=0))
    i_channel          = int(config.get('Main','i_channel'     ,fallback=1))
    i_PlotErrBars      = int(config.get('Main','i_PlotErrBars' ,fallback=1))
    Update_Inval       = int(config.get('Main','Update_Inval'  ,fallback=20))
    WindowHeight       = int(config.get('Main','WindowHeight'  ,fallback=780))
    WindowWidth        = int(config.get('Main','WindowWidth'   ,fallback=1290))
    WindowTop          = int(config.get('Main','WindowTop'     ,fallback=15))
    WindowLeft         = int(config.get('Main','WindowLeft'    ,fallback=15))

    if vs_time_datapoint == 'time': i_col_x = 1
    else :                          i_col_x = 0 
    i_ready = 0; i_new_zero = 0;
    ns_inc_Dfcbyns_inc()
    Adjusted_to_Bounds = Adjust_Pars_to_Bounds()
    Write_Config()
    ready_state = 'Select'

def Adjust_Pars_to_Bounds():
    Adjusted_to_Bounds = False
    for Key in ModelParKeys:
            if ModelPars[Key] > BoundsMax[Key]: 
                ModelPars[Key] = BoundsMax[Key]; Adjusted_to_Bounds = True
            if  ModelPars[Key] < BoundsMin[Key]: 
                ModelPars[Key] = BoundsMin[Key]; Adjusted_to_Bounds = True
    return Adjusted_to_Bounds
 
def ns_inc_Dfcbyns_inc():
    global ns_inc,iovts_inc,Dfcbyns_inc
    Dfcbyns = Dfbyns + 1j * DGbyns
    ns_inc = np.zeros(0,dtype = int); 
    iovts_inc = np.zeros(0,dtype = int); 
    Dfcbyns_inc = np.zeros(0); 
    for iovt in range(novt):
        if OvtInc[iovt] == 1:
            ns_inc      = np.append(ns_inc     ,ns[iovt] )
            iovts_inc   = np.append(iovts_inc  ,iovt          )
            Dfcbyns_inc = np.append(Dfcbyns_inc,[Dfcbyns[iovt]])
  
def StartArr_from_RheoPars():
    global GuessArr,MinArr,MaxArr
    nFPars = 0
    for Key in ModelParKeys:
        if IncInFits[Key] == 1 : nFPars += 1
    GuessArr = np.ones(nFPars)*np.nan 
    MinArr   = np.ones(nFPars)*np.nan 
    MaxArr   = np.ones(nFPars)*np.nan
    icount = 0
    for Key in ModelParKeys: 
        if IncInFits[Key] == 1:
            MinArr[icount] = BoundsMin[Key] 
            MaxArr[icount] = BoundsMax[Key]
            GuessArr[icount] = ModelPars[Key]
            if np.isnan(GuessArr[icount]) : GuessArr[icount] = 1
            if GuessArr[icount] < MinArr[icount]: GuessArr[icount] = MinArr[icount]
            if GuessArr[icount] > MaxArr[icount]: GuessArr[icount] = MaxArr[icount]
            icount += 1
 
def J_from_ModelPars(n):
    PLFac1 = (n*f_fund/f_cen)**ModelPars['PLExp1']
    PLFac2 = (n*f_fund/f_cen)**ModelPars['PLExp2']
    J = ModelPars['Par1']*PLFac1 - 1j*ModelPars['Par2']*PLFac2
    return J

def ModelPars_from_FitArr(FitArr):
    iFPar = 0
    for Key in ModelParKeys:
        if IncInFits[Key] == 1: 
            ModelPars[Key] = FitArr[iFPar]
            iFPar += 1
            
def Jp_betap_from_Df_ratio():
    global Jp_betap_from_Df_ratio_Failed
    JArr = np.ones(len(ns_inc))*np.nan
    n_cen = f_cen/f_fund
    omega_etas = 2.*np.pi*ns_inc*f_fund * SetPars['etaBulk']*1e-3
    JArr = (-Dfcbyns_inc.imag/Dfcbyns_inc.real)/omega_etas/1e-6
    try : 
        PowerLaw = linregress(np.log(ns_inc/n_cen),np.log(JArr))
        ModelPars['Par1'] = np.exp(PowerLaw.intercept)
        ModelParStdErrs['Par1'] = PowerLaw.intercept_stderr * \
            np.exp(PowerLaw.intercept)
        ModelPars['PLExp1'] = PowerLaw.slope
        ModelParStdErrs['PLExp1']=PowerLaw.stderr
        Jp_betap_from_Df_ratio_Failed = False
    except : 
        ModelPars['Par1'] = 1
        ModelPars['PLExp1'] = 0
        Jp_betap_from_Df_ratio_Failed = True
        print('Jp_betap_from_Df_ratio failed')

def MultilayerFormalism(t,J,n):
    om = 2*np.pi*n*f_fund
    t_SI       = t*1e-9
    J_SI       = J*1e-6
    rho_SI     = SetPars['rho']*1e3
    rhoBulk_SI = SetPars['rhoBulk']*1e3
    etaBulk_SI = SetPars['etaBulk']*1e-3
    Z     = (rho_SI/J_SI)**0.5; ZBulk = (1j*om*rhoBulk_SI*etaBulk_SI)**0.5
    Zrat  = ZBulk/Z; c = 1/((J_SI*rho_SI)**0.5); k = om/c
    propInterface = 1./2.*np.array([[(1+Zrat),(1-Zrat)],\
                                    [(1-Zrat),(1+Zrat)]])
    propLayer     =       np.array([[np.exp(1j*k*t_SI),0.                ],\
                                    [0.               ,np.exp(-1j*k*t_SI)]])
    amp0  = np.array([1+0j,0+0j])
    amp = np.dot(propInterface,amp0) 
    amp = np.dot(propLayer    ,amp)
    ZL = Z*(amp[0]-amp[1])/(amp[0]+amp[1])
    if RefType == 'BulkLiquid' : Dfcbyn_Model = f_fund*1j/(np.pi*Zq)*(ZL-ZBulk)/n
    if RefType == 'BareQuartz' : Dfcbyn_Model = f_fund*1j/(np.pi*Zq)*(ZL      )/n
    return Dfcbyn_Model
    
def Core_Fit():
    global FitFailed,Dfcbyns_Model
    Dfcbyns_Model = np.ones(novt,dtype = np.complex128)*np.nan
    ns_inc_Dfcbyns_inc()
    def Dfcbyns_from_FitArr(ns_inc_stacked,*FitArr):
        ModelPars_from_FitArr(FitArr)
        t = ModelPars['t']
        Dfcbyns_Model_inc = np.ones(len(iovts_inc),dtype = np.complex128)*np.nan
        for i,n in enumerate(ns_inc):
            PLFac1 = (n*f_fund/f_cen)**ModelPars['PLExp1']
            PLFac2 = (n*f_fund/f_cen)**ModelPars['PLExp2']
            J = ModelPars['Par1']*PLFac1 - 1j*ModelPars['Par2']*PLFac2
            Dfcbyns_Model_inc[i] = MultilayerFormalism(t,J,n)
        return np.hstack((Dfcbyns_Model_inc.real,Dfcbyns_Model_inc.imag)) 
    FitFailed = False; 
    if DfRatType in ['Jp','betap','Jp_betap']:
        Jp_betap_from_Df_ratio()
        if Jp_betap_from_Df_ratio_Failed : 
            FitFailed = True; FitDone = 'no'
    if not FitFailed : 
        StartArr_from_RheoPars()
        ns_inc_stacked = np.hstack((ns_inc,ns_inc))
        Dfcbyns_inc_stacked = np.hstack((Dfcbyns_inc.real,Dfcbyns_inc.imag))
        try : 
            sig = np.ones(2*len(ns_inc))*np.nan
            for i,n in enumerate(ns_inc): 
                if stat_weight == stat_weight_strings[0]: sig[i] = (1/n)**0.5
                if stat_weight == stat_weight_strings[1]: sig[i] = (1/n)**0.25
                if stat_weight == stat_weight_strings[2]: sig[i] = 1
                if stat_weight == stat_weight_strings[3]: sig[i] = n**0.25
                if stat_weight == stat_weight_strings[4]: sig[i] = n**0.5
                sig[i+len(ns_inc)] = sig[i]/RelWeight_DfDG
            popt,pcov = curve_fit(Dfcbyns_from_FitArr,\
                ns_inc_stacked,Dfcbyns_inc_stacked,p0=GuessArr,sigma=sig,bounds=(MinArr,MaxArr))
            FitFailed = False; FitDone = 'yes';
            iFPar = 0
            for Key in ModelParKeys:
                if IncInFits[Key] == 1: 
                    ModelPars[Key      ] = popt[iFPar]
                    ModelParStdErrs[Key] = pcov[iFPar,iFPar]**0.5
                    iFPar += 1
            for iovt,n in enumerate(ns):
                PLFac1 = (n*f_fund/f_cen)**ModelPars['PLExp1']
                PLFac2 = (n*f_fund/f_cen)**ModelPars['PLExp2']
                J = ModelPars['Par1']*PLFac1 - 1j*ModelPars['Par2']*PLFac2
                if OvtInc[iovt]: Dfcbyns_Model[iovt] = MultilayerFormalism(ModelPars['t'],J,n)
        except : 
                FitFailed = True; FitDone = 'no'; print('Fit failed')
        RheoPars['Par1'],RheoPars['Par2'],RheoPars['PLExp1'],RheoPars['PLExp2'] = \
        RheoPars_from_ModelPars(RheoType) 
    return FitDone        
 
def Calc_chi2():
    global chi2
    n_cen = f_cen/f_fund
    Dfcbyns_Model_inc = np.ones(len(ns_inc),dtype=np.complex128)*np.nan
    chi2 = 0
    for i,n in enumerate(ns_inc):
        J = J_from_ModelPars(n)
        Dfcbyns_Model_inc[i] = MultilayerFormalism(ModelPars['t'],J,n)
        res = Dfcbyns_Model_inc[i].real - Dfcbyns_inc[i].real + \
             (Dfcbyns_Model_inc[i].imag - Dfcbyns_inc[i].imag)*RelWeight_DfDG**0.5  
        if stat_weight == 'n^-1'    : chi2 += np.abs(res)**2*(n/n_cen)**-1 
        if stat_weight == 'n^-(0.5)': chi2 += np.abs(res)**2*(n/n_cen)**-0.5
        if stat_weight == 'flat'    : chi2 += np.abs(res)**2
        if stat_weight == 'n^(0.5)' : chi2 += np.abs(res)**2*(n/n_cen)**0.5
        if stat_weight == 'n^1'     : chi2 += np.abs(res)**2*(n/n_cen)**1
    chi2 /= ErrDfbyn**2   
    nfree = 2 * np.sum(OvtInc) - nFPars
    if nfree > 0: chi2 /= nfree 
    else        : chi2 = np.nan

def Simulate():
    global nsSim,DfcbynsSim
    nsSim = np.linspace(ns[0],ns[-1],int(len(ns)*10))
    DfcbynsSim = np.ones(len(nsSim),dtype = np.complex128)*np.nan

    for iSim,nSim in enumerate(nsSim):
        J = J_from_ModelPars(nSim)
        DfcbynsSim[iSim] = MultilayerFormalism(ModelPars['t'],J,nSim)

def RheoPars_from_ModelPars(Rheotype_new):
    Js = np.ones(novt,dtype=np.complex128)*np.nan
    oms = 2.*np.pi*f_fund*ns
    n_cen = f_cen / f_fund
    for iovt,n in enumerate(ns):
        Js[iovt] = J_from_ModelPars(n)
    if Rheotype_new == 'Jp_Jpp' :
        RheoPars1 = Js.real
        RheoPars2 = -Js.imag
    if Rheotype_new == 'Gp_Gpp' :
        try : Gs = 1/Js
        except : Gs = np.ones(len(Js))*np.nan
        RheoPars1 = Gs.real
        RheoPars2 = Gs.imag
    if Rheotype_new == 'etap_etapp' :
        try : Gs = 1/Js
        except : Gs = np.ones(len(Js))*np.nan
        etas = Gs*1e6/(1j*oms)/1e-3
        RheoPars1 =  etas.real
        RheoPars2 = -etas.imag
    if Rheotype_new == 'Gp_etap' :
        try : Gs = 1/Js
        except : Gs = np.ones(len(Js))*np.nan
        etas = Gs*1e6/(1j * oms)/1e-3
        RheoPars1 = Gs.real
        RheoPars2 = etas.real
    if Rheotype_new == '|J|_tandel' :
        Jabs = np.abs(Js)
        tandel = -Js.imag/Js.real
        RheoPars1 = Jabs
        RheoPars2 = tandel
    if Rheotype_new == '|G|_tandel' :
        try : Gs = 1/Js
        except : Gs = np.ones(len(Js))*np.nan
        Gabs = np.abs(Gs)
        tandel = Gs.imag/Gs.real
        RheoPars1 = Gabs
        RheoPars2 = tandel
    if Rheotype_new == '|eta|_tandel' :
        try : Gs = 1/Js
        except : Gs = np.ones(len(Js))*np.nan
        etas = Gs*1e6/(1j * oms)/1e-3
        etaabs = np.abs(etas)
        tandel = -etas.real/etas.imag
        RheoPars1 = etaabs
        RheoPars2 = tandel
    # new values for RheoPars at center frequency and power-law exponents 
    if Rheotype_new in ['Jp_Jpp','Gp_Gpp','etap_etapp','Gp_etap']:
        if np.min(np.abs(RheoPars1)) > 0:
            mask = np.isfinite(RheoPars1)
            PowerLaw = linregress(np.log(ns/n_cen)[mask],np.log(np.abs(RheoPars1))[mask])
            Par1_new = np.exp(PowerLaw.intercept)
            PLExp1_new = PowerLaw.slope 
        else: 
            Par1_new = 1; PLExp1_new = 0 
        if np.min(np.abs(RheoPars2)) > 0:
            mask = np.isfinite(RheoPars2)
            PowerLaw = linregress(np.log(ns/n_cen)[mask],np.log(np.abs(RheoPars2))[mask])
            Par2_new = np.exp(PowerLaw.intercept)
            PLExp2_new = PowerLaw.slope 
        else:   
            Par2_new = 1; PLExp2_new = 0 

    if Rheotype_new in ['|J|_tandel','|G|_tandel','|eta|_tandel']:
        tan = RheoPars2
        cos = 1./(1.+ tan**2)**0.5
        sin = tan * cos
        RheoPars_re = RheoPars1*cos 
        RheoPars_im = RheoPars1*sin 
        if np.min(np.abs(RheoPars_re)) > 0:
            mask = np.isfinite(RheoPars_re)
            PowerLaw = linregress(np.log(ns/n_cen),np.log(np.abs(RheoPars_re)))
            RheoPar_re_new = np.exp(PowerLaw.intercept)
            PLExp1_new = PowerLaw.slope 
        else: 
            RheoPar_re_new = 1; PLExp1_new = 0 
        if np.min(np.abs(RheoPars_im)) > 0:
            mask = np.isfinite(RheoPars_im)
            PowerLaw = linregress(np.log(ns/n_cen),np.log(np.abs(RheoPars_im)))
            RheoPar_im_new = np.exp(PowerLaw.intercept)
            PLExp2_new = PowerLaw.slope 
        else:   
            RheoPar_im_new = 1; PLExp2_new = 0
        Par1_new = (RheoPar_re_new**2+RheoPar_im_new**2)**0.5
        if np.abs(RheoPar_re_new) > 1e-9:
            Par2_new = RheoPar_im_new/RheoPar_re_new
        else : Par2_new = 1e9    
    return Par1_new,Par2_new,PLExp1_new,PLExp2_new

def ConvertFPars():
    ModelPars_old = {}
    for Key in ModelParKeys : 
        ModelPars_old[Key] = ModelPars[Key]
    for it in range(len(IO.FPars)):
        ModelPars['Par1'] = IO.FPars[it,4]
        ModelPars['Par2'] = IO.FPars[it,6]        
        ModelPars['PLExp1'] = IO.FPars[it,8]
        ModelPars['PLExp2'] = IO.FPars[it,10]
        if not np.isnan(ModelPars['Par1'])   and not np.isnan(ModelPars['Par2'  ]) and \
           not np.isnan(ModelPars['PLExp1']) and not np.isnan(ModelPars['PLExp2']):   
            IO.FPars[it,-5],IO.FPars[it,-4],\
            IO.FPars[it,-3],IO.FPars[it,-2] = \
                RheoPars_from_ModelPars(RheoType)
        if not np.isnan(IO.FPars[i_selec,4]) and not np.isnan(IO.FPars[i_selec,6]) and \
           not np.isnan(IO.FPars[i_selec,8]) and not np.isnan(IO.FPars[i_selec,10]):
            ModelPars['Par1'] = IO.FPars[i_selec,4]
            ModelPars['Par2'] = IO.FPars[i_selec,6]        
            ModelPars['PLExp1'] = IO.FPars[i_selec,8]
            ModelPars['PLExp2'] = IO.FPars[i_selec,10]
    for Key in ModelParKeys : 
        ModelPars[Key] = ModelPars_old[Key]
                                   