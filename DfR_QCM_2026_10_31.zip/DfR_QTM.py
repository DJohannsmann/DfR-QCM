import numpy as np
import tkinter as tk
from tkinter import filedialog as fd
import DfR_QTM_Core as Cor
import DfR_QTM_IO as IO
import DfR_QTM_chi2_Landscape as chi2_Landscape
import DfR_QTM_RndNoise as RndNoise

from matplotlib.backends.backend_tkagg import(FigureCanvasTkAgg)
from matplotlib.figure import Figure

import shutil
import os
import pandas as pd
import webbrowser

from io import BytesIO
import win32clipboard
from PIL import Image

def Graph_to_Clipboard(File):
    def send_to_clipboard(clip_type,data):
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(clip_type,data)
        win32clipboard.CloseClipboard()
    graph = Image.open(File)
    output = BytesIO(); graph.convert('RGB').save(output, 'BMP')
    data = output.getvalue()[14:]; output.close()
    send_to_clipboard(win32clipboard.CF_DIB, data)
    
def Vals_to_Clipboard(File,header): 
    Vals_in = np.loadtxt(File,skiprows = 1)
    Vals = np.zeros((0,len(Vals_in[0])),dtype=float)
    for i in range(len(Vals_in)):
        All_nans = True
        for j in range(2,len(Vals_in[i])):
            if not np.isnan(Vals_in[i,j]) : All_nans = False
        if not All_nans:
            Vals = np.append(Vals,[Vals_in[i]],axis=0)
    columns = header.split('\t') 
    Valsdf = pd.DataFrame(Vals,columns=columns)
    Valsdf.to_clipboard(excel=True,sep=None,index=False)

def Clear_Fits():
    for j in range(len(IO.FPars[0])) : IO.FPars[:,j] = np.nan
    for j in range(len(IO.Shifts)):     
        for iovt in range(Cor.novt):  
            IO.Shifts[j,2+4*iovt+2]= np.nan
            IO.Shifts[j,2+4*iovt+3]= np.nan
    IO.Make_headers()
    np.savetxt(os.getcwd()+'/tmp/FPars.qtm'           ,IO.FPars,header=IO.header_FPars,delimiter='\t',newline='\n')
    np.savetxt(os.getcwd()+'/tmp/FPars_for_unhide.qtm',IO.FPars,header=IO.header_FPars,delimiter='\t',newline='\n')
    PlotFPars(PlotFParsFrame)
    PlotShifts(PlotShiftsFrame)
    IO.Make_headers()            

def Calc_nFPars():
    Cor.nFPars = 0
    for Key in Cor.ModelParKeys: 
        if Cor.IncInFits[Key] == 1: Cor.nFPars += 1
        
def Import_Shifts_w_Dialog():
    AskforImportPath(); Import_Shifts()

def AskforImportPath():
    if Cor.ImportFormat in ['from QTZ (.qtz)']: 
        filetypes = [('qtz files','*.qtz')]
    elif Cor.ImportFormat in ['from QSoft','from QSoft New','from AWSensors','from OpenQCM','from QCM-I']: 
        filetypes = [('text files','*.txt')]
    elif Cor.ImportFormat in ['from 3TAnalytik']: 
        filetypes = [('3T files','*.3td')]
    else : filetypes = filetypes = [('text files','*.txt'),('dat files','*.dat'),('3T files','*.3td')]    
    Cor.SourceFilePath = fd.askopenfilename(filetypes=filetypes)

def Import_Shifts():
    Cor.Write_Config(); Cor.Read_Config()    
    Root.update(); Clear_Fits(); Clear()
    IO.Import_Shifts() 
    Cor.i_selec = 0
    while All_NaNs_in_Dfcs() and Cor.i_selec < len(IO.Shifts) - 1:
        Cor.i_selec += 1
    for iovt in range(Cor.novt): 
        Cor.Dfbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt]  
        Cor.DGbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt+1]  
    PlotShifts(PlotShiftsFrame) 
    PlotFPars(PlotFParsFrame)
    MakeDfDGbynsFrame(DfDGbynsFrame); PlotSingle(PlotSingleFrame)
    MakeParsFrame(ParsFrame)
    MakeImportFrame(ImportFrame)
    Update_Previous_Importnames()
    Root.title('DfR-QTM: ' + os.path.basename(Cor.SourceFilePath))

def Fit():
    Check_for_NaNs_in_Dfcs(); Calc_nFPars()
    if 2*np.sum(Cor.OvtInc) < Cor.nFPars: 
        tk.messagebox.showinfo('','number of fit parameters > 2 * number of active overtones'); return
    if Cor.nFPars == 0: 
        tk.messagebox.showinfo('','no active fit parameters'); return
    Cor.FitDone = Cor.Core_Fit(); Cor.Write_Config()
    PlotSingle(PlotSingleFrame)
    MakeParsFrame(ParsFrame)
    MakeFitFrame(FitFrame)

def Fit_All():
    def Save_Fit_Results():
        IO.Make_headers()
        np.savetxt(os.getcwd()+'/tmp/Shifts.qtm'           ,IO.Shifts,header=IO.header_Shifts,delimiter='\t',newline='\n')
        np.savetxt(os.getcwd()+'/tmp/Shifts_for_unhide.qtm',IO.Shifts,header=IO.header_Shifts,delimiter='\t',newline='\n')
        np.savetxt(os.getcwd()+'/tmp/FPars.qtm'            ,IO.FPars ,header=IO.header_FPars ,delimiter='\t',newline='\n')
        np.savetxt(os.getcwd()+'/tmp/FPars_for_unhide.qtm' ,IO.FPars ,header=IO.header_FPars ,delimiter='\t',newline='\n')

    if Cor.Abort_Enabled: Cor.Abort = True; return
    Cor.Abort = False; Cor.Abort_Enabled = True; Fit_All_Btn['text'] = 'Abort'; 
    Root.update(); Calc_nFPars()
    if Cor.nFPars == 0: tk.messagebox.showinfo('','no active fit parameters')
    else:
        for it in range(Cor.i_start_fit,Cor.i_stop_fit):
            if Cor.Abort:
                Save_Fit_Results(); Cor.Abort_Enabled = False; Cor.Abort = False
                Fit_All_Btn['text'] = 'Fit All'; Root.update()
                return
            Cor.i_current = it
            Cor.FitDone = 'yes'
            for iovt in range(Cor.novt): 
                Cor.Dfbyns[iovt] = IO.Shifts[it,2+4*iovt  ]
                Cor.DGbyns[iovt] = IO.Shifts[it,2+4*iovt+1]
            Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
            no_nans = True
            for iovt in range(Cor.novt):
                if Cor.OvtInc[iovt] and np.isnan(Cor.Dfcbyns[iovt]): no_nans = False
            if no_nans: 
                Cor.FitDone = Cor.Core_Fit()
            if no_nans and not Cor.FitFailed:
                IO.FPars[it,0] = it
                IO.FPars[it,1] = IO.Shifts[it,1]
                for i,Key in enumerate(Cor.ModelParKeys):
                    IO.FPars[it,2+2*i]   = Cor.ModelPars[Key]
                    IO.FPars[it,2+2*i+1] = Cor.ModelParStdErrs[Key]
                for i,Key in enumerate(Cor.RheoParKeys):
                    IO.FPars[it,2+2*5+i]   = Cor.RheoPars[Key]
                    Cor.Calc_chi2(); IO.FPars[it,-1] = Cor.chi2;
                for iovt in range(len(Cor.ns)):
                    IO.Shifts[it,2+4*iovt+2] = Cor.Dfcbyns_Model[iovt].real
                    IO.Shifts[it,2+4*iovt+3] = Cor.Dfcbyns_Model[iovt].imag
                if (it-Cor.i_start_fit)%Cor.Update_Inval == Cor.Update_Inval-1: 
                    Cor.Write_Config()
                    Cor.i_selec = it
                    MakeParsFrame(ParsFrame)
                    PlotSingle(PlotSingleFrame)
                    PlotShifts(PlotShiftsFrame)
                    PlotFPars(PlotFParsFrame)
                    Root.update()
            else:
                for i in range(15): 
                    IO.FPars[it,2+i] * np.nan 
                for iovt in range(len(Cor.ns)):
                    IO.Shifts[it,2+4*iovt+2] = np.nan
                    IO.Shifts[it,2+4*iovt+3] = np.nan

    Save_Fit_Results()
    MakeParsFrame(ParsFrame)
    PlotShifts(PlotShiftsFrame)   
    PlotFPars(PlotFParsFrame)
    Fit_All_Btn['text'] = 'Fit All'; Cor.Abort_Enabled = False; Cor.FitDone = 'yes';

def Check_for_NaNs_in_Dfcs():
    OvtInc_Changed = False
    OvtInc_old = np.copy(Cor.OvtInc)
    nans_ovts = np.ones((Cor.novt),dtype = int)
    for it in range(len(IO.Shifts)):
        for iovt in range(Cor.novt): 
            if not np.isnan(IO.Shifts[it,2+4*iovt  ]) or \
               not np.isnan(IO.Shifts[it,2+4*iovt+1]):  nans_ovts[iovt] = 0
    for iovt in range(Cor.novt):
        if nans_ovts[iovt] == 1 : Cor.OvtInc[iovt] = 0
    if OvtInc_old[iovt] != Cor.OvtInc[iovt]: OvtInc_Changed = True
    if OvtInc_Changed: 
        Cor.Write_Config()
        MakeDfDGbynsFrame(DfDGbynsFrame)

def All_NaNs_in_Dfcs():
    All_NaNs = True
    for iovt in range(Cor.novt): 
        if not np.isnan(IO.Shifts[Cor.i_selec,2+4*iovt  ]) or \
           not np.isnan(IO.Shifts[Cor.i_selec,2+4*iovt+1]): All_NaNs = False
    return All_NaNs    

def All_NaNs_in_array(array):
    All_NaNs = True
    for i in range(len(array)): 
        if not np.isnan(array[i]): All_NaNs = False
    return All_NaNs    

def PlotSingle(cntr):
    def Graph2Clpbd(): Graph_to_Clipboard(os.getcwd()+'/tmp/Single.png')

    Cor.ns_inc_Dfcbyns_inc(); Cor.Simulate() 
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (SinglePlotWidth,SinglePlotHeight),dpi=mydpi) 
    axis = fig.add_subplot(211)
    if np.sum(Cor.OvtInc) > 0: 
        axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.real,'x',c='r',label='\u0394f/n [Hz]',\
                  markersize = 6)
    axis.plot(    Cor.nsSim *Cor.f_fund/1e6,Cor.DfcbynsSim.real,'-',c='r',markersize = 6)
    axis.tick_params(labelsize=7,direction='in')
    axis.axes.xaxis.set_ticklabels([])
    axis.set_ylabel('\u0394f/n [Hz]',fontsize=8)
    
    axis = fig.add_subplot(212)
    if Cor.DD_DGbyn == 'DD':
        if np.sum(Cor.OvtInc) > 0: 
            axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.imag*(Cor.f_fund/2.*1e-6),'x',c='b',markersize = 6)
        axis.plot(    Cor.nsSim *Cor.f_fund/1e6,Cor.DfcbynsSim.imag *(Cor.f_fund/2.*1e-6),'-',c='b',markersize = 6)
    if Cor.DD_DGbyn == 'DGbyn': 
        if np.sum(Cor.OvtInc) > 0: 
            axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.imag,'x',c='b',markersize = 6)
        axis.plot(    Cor.nsSim *Cor.f_fund/1e6,Cor.DfcbynsSim.imag ,'-',c='b',markersize = 6)
    axis.tick_params(labelsize=7,direction='in')
    axis.set_xlabel('f [MHz]',fontsize=8)
    if Cor.DD_DGbyn == 'DD'   : axis.set_ylabel('\u0394D [10\u207B\u2076]',fontsize=8)
    if Cor.DD_DGbyn == 'DGbyn': axis.set_ylabel('\u0394\u0393/n [Hz]',fontsize=8)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw() 
    canvas.get_tk_widget().grid(row=0,column=0,columnspan=2,sticky='NW')
    DfDGbyn_sim = [Cor.nsSim*Cor.f_fund/1e6]
    DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.DfcbynsSim.real],axis=0)
    if Cor.DD_DGbyn == 'DGbyn':
        header =  'f[MHz] \t Dfbyn[Hz] \t DGbyn[Hz]'
        DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.DfcbynsSim.imag],axis=0)
    if Cor.DD_DGbyn == 'DD':
        header = 'f[MHz] \t Dfbyn[Hz] \t DD[10^-6]'
        DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.DfcbynsSim.imag/Cor.f_fund*2./1e-6],axis=0)
    np.savetxt(os.getcwd()+'/tmp/DfDGbyn_Single_sim.qtm',np.transpose(DfDGbyn_sim),header=header,delimiter='\t',newline='\n')    
    if np.sum(Cor.OvtInc) > 0:
        DfDGbyn_Exp = [Cor.ns_inc*Cor.f_fund/1e6]
        DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.real],axis=0)
        if Cor.DD_DGbyn == 'DGbyn':
            header='f[MHz] \t Dfbyn[Hz] \t DGbyn[Hz]'
            DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.imag],axis=0)
        if Cor.DD_DGbyn == 'DD':
            header = 'f[MHz] \t Dfbyn[Hz] \t DD[10^-6]'
            DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.imag/Cor.f_fund*2./1e-6],axis=0)
        np.savetxt(os.getcwd()+'/tmp/DfDGbyn_Single_expt.qtm',np.transpose(DfDGbyn_Exp),header = header,delimiter='\t',newline='\n')    
    suptitletext = ''
    if len(Cor.InfoString) > 0: suptitletext = Cor.InfoString
    else                      : suptitletext = ''
    if len(IO.Shifts) > 1: 
        suptitletext += '  time: ' + str(np.round(IO.Shifts[Cor.i_selec,Cor.i_col_x],1))
    if Cor.ImportFormat == 'from QSoft_new': 
        suptitletext +=  '\n' + Cor.SourceFilePathstr + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + Cor.SourceFilePathstr
    if Cor.DfRatType == 'Jp_betap' : suptitletext += '   DfR \u2192 J\',\u03B2\''     
    if Cor.DfRatType == 'Jp'       : suptitletext += '   DfR \u2192 J\''      
    if Cor.DfRatType == 'betap'    : suptitletext += '   DfR \u2192 \u03B2\''      
    if Cor.DfRatType == 'none'     : suptitletext += '   DfR \u2192 none'      
    fig.suptitle(suptitletext,fontsize = 8)
    fig.tight_layout(); 
    fig.savefig(os.getcwd()+'/tmp/Single.png',dpi=mydpi)
    Graph_to_Clpbd_Btn = tk.Button(cntr,text =' Graph \u2192 Clipbd',command=Graph2Clpbd)
    Graph_to_Clpbd_Btn.grid(row=1,column=0,sticky='W')

def PlotShifts(cntr):
    global FitRange_Btn,Hide_1_Btn,Zoom_Btn,Avrg_Btn

    def Hide_1_Shifts():     Cor.ready_state = 'Hide_1_Shifts';     Root.config(cursor='hand2'); Hide_1_Btn['bg'] = 'lightgrey'
    def Hide_Range_Shifts(): Cor.ready_state = 'Hide_Range_Shifts'; Root.config(cursor='hand2'); Hide_Range_Btn['bg'] = 'lightgrey'
    def Zoom_Shifts():       Cor.ready_state = 'Zoom_Shifts';       Root.config(cursor='hand2'); Zoom_Btn['bg'] = 'lightgrey'
    def Avrg():              Cor.ready_state = 'Average';           Root.config(cursor='hand2'); Avrg_Btn['bg'] = 'lightgrey'
    def UnZoom_Shifts():     Cor.i_start_zoom_Shifts = 0; Cor.i_stop_zoom_Shifts = len(IO.Shifts); PlotShifts(PlotShiftsFrame)
    def Graph2Clpbd():       Graph_to_Clipboard(os.getcwd()+'/tmp/Shifts.png')
    def Vals2Clpbd() :       Vals_to_Clipboard( os.getcwd()+'/tmp/Shifts.qtm',IO.header_Shifts)
    
    def UnHide_Shifts():
        Cor.i_start_hide_Shifts = 0
        Cor.i_stop_hide_Shifts = 0
        IO.Shifts = np.loadtxt(os.getcwd()+'/tmp/Shifts_for_unhide.qtm',skiprows=1)
        np.savetxt(os.getcwd()+'/tmp/Shifts.qtm',IO.Shifts,header=IO.header_Shifts,delimiter='\t',newline='\n')
        PlotShifts(PlotShiftsFrame)
        MakeImportFrame(ImportFrame)
        Cor.Write_Config()
        
    def onclick_Shifts(event):
        if Cor.ready_state == 'Select' and event.xdata != None:
            Cor.i_selec = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x])))
            Cor.i_start_avrg = 0
            Cor.i_stop_avrg = 0
            it = Cor.i_selec
            for iovt in range(Cor.novt):
                Cor.Dfbyns[iovt] = IO.Shifts[it,2+4*iovt  ]
                Cor.DGbyns[iovt] = IO.Shifts[it,2+4*iovt+1]
            Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
            Cor.Write_Config()
            PlotSingle(PlotSingleFrame)
            PlotShifts(PlotShiftsFrame)
            MakeDfDGbynsFrame(DfDGbynsFrame)

        if Cor.ready_state == 'FitRange': 
            Cor.i_start_fit= int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x]))) 
            Cor.i_current = Cor.i_start_fit
        if Cor.ready_state == 'Hide_Range_Shifts': 
            Cor.i_start_hide_Shifts = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x]))) 
        if Cor.ready_state == 'Zoom_Shifts':       
            Cor.i_start_zoom_Shifts = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x])))
        if Cor.ready_state == 'Average':       
            Cor.i_start_avrg    = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x])))
        if Cor.ready_state == 'Hide_1_Shifts':
            Root.config(cursor='arrow'); Cor.ready_state = 'Select'; Cor.Write_Config()
            i_Hide_1 = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x])))
            IO.Shifts[i_Hide_1,:] = np.nan
            IO.Make_headers()            
            np.savetxt(os.getcwd()+'/tmp/Shifts.qtm',IO.Shifts,header=IO.header_Shifts,delimiter='\t',newline='\n')
            PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)  
            MakeImportFrame(ImportFrame)
            Hide_1_Btn['bg'] = 'SystemButtonFace'

    def onrelease_Shifts(event):
        try: 
            if Cor.ready_state == 'FitRange':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                Cor.i_stop_fit = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x])))
                if Cor.i_stop_fit < Cor.i_start_fit: 
                    istop_fit_temp = Cor.i_stop_fit
                    Cor.i_stop_fit = Cor.i_start_fit
                    Cor.i_start_fit = istop_fit_temp
                    Cor.i_current  = Cor.i_start_fit
                Cor.Write_Config()
                MakeImportFrame(ImportFrame)
                PlotShifts(PlotShiftsFrame)
                FitRange_Btn['bg'] = 'SystemButtonFace'
        
            if Cor.ready_state == 'Hide_Range_Shifts':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                IO.Make_headers()            
                Cor.i_stop_hide_Shifts = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x]))) 
                if Cor.i_start_hide_Shifts <= Cor.i_stop_hide_Shifts: 
                    step =  1  
                    Cor.i_start_hide_Shifts -= 1
                    Cor.i_stop_hide_Shifts  += 1
                if Cor.i_start_hide_Shifts >= Cor.i_stop_hide_Shifts: 
                    step = -1  
                    Cor.i_start_hide_Shifts += 1
                    Cor.i_stop_hide_Shifts  -= 1
                for it in range(Cor.i_start_hide_Shifts,Cor.i_stop_hide_Shifts,step):
                    for j in range(len(IO.Shifts[it])):IO.Shifts[it,j] = np.nan
                np.savetxt(os.getcwd()+'/tmp/Shifts.qtm',IO.Shifts,header=IO.header_Shifts,delimiter='\t',newline='\n')
                Hide_Range_Btn['bg'] = 'SystemButtonFace'
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                if All_NaNs_in_Dfcs(): 
                    Cor.i_selec = 0
                    while All_NaNs_in_Dfcs() and Cor.i_selec < len(IO.Shifts) - 1:
                        Cor.i_selec += 1
                for iovt in range(Cor.novt):
                    Cor.Dfbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt  ]
                    Cor.DGbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt+1]
                Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns 
                Cor.Write_Config()
                PlotSingle(PlotSingleFrame)
                PlotShifts(PlotShiftsFrame)
                MakeDfDGbynsFrame(DfDGbynsFrame)
                MakeImportFrame(ImportFrame)
                Hide_Range_Btn['bg'] = 'SystemButtonFace'
            if Cor.ready_state == 'Zoom_Shifts':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select'
                Cor.i_stop_zoom_Shifts = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x]))) 
                if Cor.i_start_zoom_Shifts >= Cor.i_stop_zoom_Shifts:
                    start_buffer = Cor.i_stop_zoom_Shifts
                    Cor.i_stop_zoom_Shifts = Cor.i_start_zoom_Shifts
                    Cor.i_start_zoom_Shifts = start_buffer
                Cor.Write_Config()
                PlotShifts(PlotShiftsFrame)
                Zoom_Btn['bg'] = 'SystemButtonFace'
            if Cor.ready_state == 'Average':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                Cor.i_stop_avrg = int(np.nanargmin(np.abs(event.xdata-IO.Shifts[:,Cor.i_col_x]))) 
                if Cor.i_start_avrg >= Cor.i_stop_avrg:
                    start_buffer = Cor.i_stop_avrg
                    Cor.i_stop_avrg = Cor.i_start_avrg
                    Cor.i_start_avrg = start_buffer
                for iovt in range(Cor.novt):
                    Cor.Dfbyns[iovt] = np.nanmean(IO.Shifts[Cor.i_start_avrg:Cor.i_stop_avrg,2+4*iovt  ])
                    Cor.DGbyns[iovt] = np.nanmean(IO.Shifts[Cor.i_start_avrg:Cor.i_stop_avrg,2+4*iovt+1])
                Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns 
                Cor.Write_Config()
                PlotSingle(PlotSingleFrame)
                MakeDfDGbynsFrame(DfDGbynsFrame)
                MakeImportFrame(ImportFrame)
                Cor.i_start_avrg = 0; Cor.i_stop_avrg = 0
                Avrg_Btn['bg'] = 'SystemButtonFace'
        except: 
            pass

    Cor.i_start_zoom_Shifts = np.min([Cor.i_start_zoom_Shifts,len(IO.Shifts)-1])
    Cor.i_stop_zoom_Shifts = np.min([Cor.i_stop_zoom_Shifts,len(IO.Shifts)-1])
    Cor.Write_Config()
    if not np.isnan(IO.Shifts[Cor.i_start_zoom_Shifts,Cor.i_col_x]) and not np.isnan(IO.Shifts[Cor.i_stop_zoom_Shifts,Cor.i_col_x]):
        itmin = np.nanargmin(IO.Shifts[:,0])
        itmax = np.nanargmax(IO.Shifts[:,0])
        tmin  = np.nanmax([IO.Shifts[Cor.i_start_zoom_Shifts,Cor.i_col_x],IO.Shifts[itmin,Cor.i_col_x]])        
        tmax  = np.nanmin([IO.Shifts[Cor.i_stop_zoom_Shifts ,Cor.i_col_x],IO.Shifts[itmax,Cor.i_col_x]])
    Check_for_NaNs_in_Dfcs()
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (DfDGbynsPlotWidth,DfDGbynsPlotHeight),dpi=mydpi)
    axis = fig.add_subplot(211)
    if np.ndim(IO.Shifts) == 1: IO.Shifts = np.array([IO.Shifts])
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            axis.plot(IO.Shifts[:,Cor.i_col_x],IO.Shifts[:,2+4*iovt  ],'.',c=Cor.Colors[iovt],label = Cor.Ovt_Labels[iovt],
                      markersize=1)
            axis.plot(IO.Shifts[:,Cor.i_col_x],IO.Shifts[:,2+4*iovt+2],'-',c=Cor.Colors[iovt],linewidth=0.5)
            if not All_NaNs_in_array(IO.Shifts[:,2+4*iovt]):
                if np.nanmax(IO.Shifts[:,2+4*iovt]) > np.nanmin(IO.Shifts[:,2+4*iovt]) and \
                   Cor.i_selec < len(IO.Shifts) and Cor.i_start_fit < len(IO.Shifts) and Cor.i_stop_fit < len(IO.Shifts) \
                       and Cor.i_current < len(IO.Shifts): 
                    axis.plot(np.ones(5)*IO.Shifts[Cor.i_selec,Cor.i_col_x],\
                              np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt]),np.nanmax(IO.Shifts[:,2+4*iovt]),5),'-',c='lightsteelblue')
                    axis.plot(np.ones(5)*IO.Shifts[Cor.i_start_fit,Cor.i_col_x],\
                              np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt]),np.nanmax(IO.Shifts[:,2+4*iovt]),5),'-',c='grey')
                    axis.plot(np.ones(5)*IO.Shifts[Cor.i_stop_fit,Cor.i_col_x],\
                              np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt]),np.nanmax(IO.Shifts[:,2+4*iovt]),5),'-',c='olive')
                    axis.plot(np.ones(5)*IO.Shifts[Cor.i_current,Cor.i_col_x],\
                              np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt]),np.nanmax(IO.Shifts[:,2+4*iovt]),5),'-',c='fuchsia')
            if not np.isnan(IO.Shifts[Cor.i_start_zoom_Shifts,Cor.i_col_x]) and not np.isnan(IO.Shifts[Cor.i_stop_zoom_Shifts,Cor.i_col_x]):
                if tmax > tmin:
                    leftlim  = tmin - 0.05*(tmax-tmin)
                    rightlim = tmax + 0.05*(tmax-tmin)
                    axis.set_xlim(left =leftlim,right=rightlim)
    axis.set_ylabel('$\Delta f/n$ [Hz]',fontsize=9)
    axis.axes.xaxis.set_ticklabels([])
    axis.tick_params(direction='in',labelsize =8)
    if np.sum(Cor.OvtInc) > 0: axis.legend(fontsize=7)
    
    suptitletext = ''
    if len(Cor.InfoString) > 0: 
        suptitletext += Cor.InfoString
    if Cor.ImportFormat == 'from QSoft_new': 
        suptitletext +=  '\n' + Cor.SourceFilePathstr + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + Cor.SourceFilePathstr
    if Cor.DfRatType == 'none'     : suptitletext += '   DfR \u2192 none'      
    if Cor.DfRatType == 'Jp'       : suptitletext += '   DfR \u2192 J\''      
    if Cor.DfRatType == 'betap'    : suptitletext += '   DfR \u2192 \u03B2\''      
    if Cor.DfRatType == 'Jp_betap' : suptitletext += '   DfR \u2192 J\',\u03B2\''     
    fig.suptitle(suptitletext,fontsize = 8)
  
    axis = fig.add_subplot(212)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            if Cor.DD_DGbyn == 'DD':
                axis.plot(IO.Shifts[:,Cor.i_col_x],IO.Shifts[:,2+4*iovt+1]/Cor.f_fund*2./1e-6,'.',c=Cor.Colors[iovt],\
                          label = Cor.Ovt_Labels[iovt],markersize=1)
                axis.plot(IO.Shifts[:,Cor.i_col_x],IO.Shifts[:,2+4*iovt+3]/Cor.f_fund*2./1e-6,'-',c=Cor.Colors[iovt],linewidth=0.5)
                if not All_NaNs_in_array(IO.Shifts[:,2+4*iovt+1]):
                    if np.nanmax(IO.Shifts[:,2+4*iovt]) > np.nanmin(IO.Shifts[:,2+4*iovt]) and \
                       Cor.i_selec < len(IO.Shifts) and Cor.i_start_fit < len(IO.Shifts) and Cor.i_stop_fit < len(IO.Shifts): 
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_selec,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',c='lightsteelblue')
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_start_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',c='grey')
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_stop_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',c='olive')
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_current,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',c='fuchsia')
            if Cor.DD_DGbyn == 'DGbyn':
                axis.plot(IO.Shifts[:,Cor.i_col_x],IO.Shifts[:,2+4*iovt+1],'.',c=Cor.Colors[iovt],\
                          label = Cor.Ovt_Labels[iovt],markersize=1)
                axis.plot(IO.Shifts[:,Cor.i_col_x],IO.Shifts[:,2+4*iovt+3],'-',c=Cor.Colors[iovt],linewidth=0.5)
                if not All_NaNs_in_array(IO.Shifts[:,2+4*iovt+1]):
                    if np.nanmax(IO.Shifts[:,2+4*iovt]) > np.nanmin(IO.Shifts[:,2+4*iovt]) and \
                       Cor.i_selec < len(IO.Shifts) and Cor.i_start_fit < len(IO.Shifts) and Cor.i_stop_fit < len(IO.Shifts): 
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_selec,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5),'-',c='lightsteelblue')
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_start_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5),'-',c='grey')
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_stop_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5),'-',c='olive')
                        axis.plot(np.ones(5)*IO.Shifts[Cor.i_current,Cor.i_col_x],\
                                  np.linspace(np.nanmin(IO.Shifts[:,2+4*iovt+1]),np.nanmax(IO.Shifts[:,2+4*iovt+1]),5),'-',c='fuchsia')
            if not np.isnan(IO.Shifts[Cor.i_start_zoom_Shifts,Cor.i_col_x]) and not np.isnan(IO.Shifts[Cor.i_stop_zoom_Shifts,Cor.i_col_x]):
                if tmax > tmin:
                    leftlim  = tmin - 0.05*(tmax-tmin)
                    rightlim = tmax + 0.05*(tmax-tmin)
                    axis.set_xlim(left = leftlim,right=rightlim)
    if Cor.vs_time_datapoint == 'time'     : axis.set_xlabel('time ['+ Cor.TimeUnit+']',fontsize=9)
    if Cor.vs_time_datapoint == 'datapoint': axis.set_xlabel('number',fontsize=9)
    if Cor.DD_DGbyn == 'DD'   : axis.set_ylabel('\u0394D [10\u207B\u2076]',fontsize=9)
    if Cor.DD_DGbyn == 'DGbyn': axis.set_ylabel('$\Delta\Gamma/n$ [Hz]'   ,fontsize=9)
    axis.tick_params(direction='in',labelsize=8)
    fig.tight_layout(); fig.savefig(os.getcwd()+'/tmp/Shifts.png',dpi=200)

    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); 
    canvas.get_tk_widget().grid(row=0,column=0,columnspan=7,sticky='NW')
    fig.canvas.mpl_connect('button_press_event'  ,onclick_Shifts)
    fig.canvas.mpl_connect('button_release_event',onrelease_Shifts)
    
    Hide_1_Btn = tk.Button(cntr,text ='Hide Point',command=Hide_1_Shifts)
    Hide_1_Btn.grid(row=1,column=0,sticky='W')
    Hide_Range_Btn = tk.Button(cntr,text ='Hide Range',command=Hide_Range_Shifts)
    Hide_Range_Btn.grid(row=1,column=1,sticky='W')
    Unhide_Btn = tk.Button(cntr,text ='Unhide',command=UnHide_Shifts)
    Unhide_Btn.grid(row=1,column=2,sticky='W')
    Zoom_Btn = tk.Button(cntr,text ='Zoom',command=Zoom_Shifts)
    Zoom_Btn.grid(row=2,column=0,columnspan=2,sticky='W')
    UnZoom_Btn = tk.Button(cntr,text ='Unzoom',command=UnZoom_Shifts)
    UnZoom_Btn.grid(row=2,column=1,columnspan=2,sticky='W')
    Avrg_Btn = tk.Button(cntr,text ='Average',command=Avrg)
    Avrg_Btn.grid(row=2,column=2,sticky='W')
    Graph_to_Clpbd_Btn = tk.Button(cntr,text =' Graph \u2192 Clipbd',command=Graph2Clpbd)
    Graph_to_Clpbd_Btn.grid(row=4,column=0,columnspan=2,sticky='W')
    Vals_to_Clpbd_Btn = tk.Button(cntr,text ='Vals \u2192 Clipbd',command=Vals2Clpbd)
    Vals_to_Clpbd_Btn.grid(row=4,column=2,sticky='W')
    
    def Select_FitRange(): 
        Cor.ready_state = 'FitRange'; Root.config(cursor='hand2'); FitRange_Btn['bg'] = 'lightgrey'
    FitRange_Btn = tk.Button(cntr,text ='Select Fit Range',command=Select_FitRange)
    FitRange_Btn.grid(row=3,column=0,columnspan=2,sticky='W')

def PlotFPars(cntr):
    global FPs_Hide_1_Btn,FPs_Hide_Range_Btn,FPs_Zoom_Btn
    def Hide_1_FP()    : Cor.ready_state = 'Hide_1_FP';     Root.config(cursor='hand2'); FPs_Hide_1_Btn['bg'] = 'lightgrey'
    def Hide_Range_FP(): Cor.ready_state = 'Hide_Range_FP'; Root.config(cursor='hand2'); FPs_Hide_Range_Btn['bg'] = 'lightgrey'
    def Zoom_FP()      : Cor.ready_state = 'Zoom_FP';       Root.config(cursor='hand2'); FPs_Zoom_Btn['bg'] = 'lightgrey'
    def UnZoom_FP()    : Cor.i_start_zoom_FP = 0; Cor.i_stop_zoom_FP = len(IO.FPars); PlotFPars(PlotFParsFrame)
    def Graph2Clpbd()  : Graph_to_Clipboard(os.getcwd()+'/tmp/FPars.png')
    def Vals2Clpbd()   : Vals_to_Clipboard( os.getcwd()+'/tmp/FPars.qtm',IO.header_FPars)

    def Unhide_FP():
        Cor.i_start_hide_FP = 0
        Cor.i_stop_hide_FP = 0
        data = np.loadtxt(os.getcwd()+'/tmp/FPars_for_unhide.qtm',skiprows=1)
        if data.ndim == 1: data = np.array([data])
        for it in range(len(data)):
            for j in range(len(data[0])):
                try: IO.FPars[it,j] = data[it,j]
                except: pass
        np.savetxt(os.getcwd()+'/tmp/FPars.qtm',IO.FPars,header=IO.header_FPars,delimiter='\t',newline='\n')
        PlotFPars(PlotFParsFrame)

    def onclick_FP(event):
        if Cor.ready_state == 'Hide_Range_FP': 
            Cor.i_start_hide_FP = int(np.nanargmin(np.abs(event.xdata-IO.FPars[:,Cor.i_col_x]))) 
        if Cor.ready_state == 'Zoom_FP': 
            Cor.i_start_zoom_FP = int(np.nanargmin(np.abs(event.xdata-IO.FPars[:,Cor.i_col_x]))) 
        if Cor.ready_state == 'Hide_1_FP':
            Root.config(cursor='arrow'); Cor.ready_state = 'Select'; Cor.Write_Config()
            if np.isnan(event.xdata):
                FPs_Hide_1_Btn['bg'] = 'SystemButtonFace'; return
            i_Hide_1_FP = int(np.nanargmin(np.abs(event.xdata-IO.FPars[:,Cor.i_col_x])))
            IO.FPars[i_Hide_1_FP,:] = np.nan
            np.savetxt(os.getcwd()+'/tmp/FPars.qtm',IO.FPars,header=IO.header_FPars,delimiter='\t',newline='\n')
            PlotFPars(PlotFParsFrame) 
            FPs_Hide_1_Btn['bg'] = 'SystemButtonFace'

    def onrelease_FP(event):
        try: 
            if Cor.ready_state == 'Hide_Range_FP':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                IO.Make_headers()            
                Cor.i_stop_hide_FP = int(np.nanargmin(np.abs(event.xdata-IO.FPars[:,Cor.i_col_x]))) 
                if Cor.i_start_hide_FP <= Cor.i_stop_hide_FP: 
                    step =  1  
                    Cor.i_start_hide_FP -= 1
                    Cor.i_stop_hide_FP  += 1
                if Cor.i_start_hide_FP >= Cor.i_stop_hide_FP: 
                    step = -1  
                    Cor.i_start_hide_FP += 1
                    Cor.i_stop_hide_FP  -= 1
                for it in range(Cor.i_start_hide_FP,Cor.i_stop_hide_FP,step):
                    for j in range(len(IO.FPars[it])):IO.FPars[it,j] = np.nan
                np.savetxt(os.getcwd()+'/tmp/FPars.qtm',IO.FPars,header=IO.header_FPars,delimiter='\t',newline='\n')
                PlotFPars(PlotFParsFrame) 
                FPs_Hide_Range_Btn['bg'] = 'SystemButtonFace'
            
            if Cor.ready_state == 'Zoom_FP':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                Cor.i_stop_zoom_FP = int(np.nanargmin(np.abs(event.xdata-IO.FPars[:,Cor.i_col_x]))) 
                if Cor.i_start_zoom_FP >= Cor.i_stop_zoom_FP:
                    start_buffer = Cor.i_stop_zoom_FP
                    Cor.i_stop_zoom_FP = Cor.i_start_zoom_FP
                    Cor.i_start_zoom_FP = start_buffer
                PlotFPars(PlotFParsFrame) 
                FPs_Zoom_Btn['bg'] = 'SystemButtonFace'
        except: 
            print(Cor.ready_state + 'failed')
    
    Cor.i_start_zoom_FP = np.min([Cor.i_start_zoom_FP,len(IO.FPars)-1])
    Cor.i_stop_zoom_FP = np.min([Cor.i_stop_zoom_FP,len(IO.FPars)-1])
    Cor.Write_Config()
    if not np.isnan(IO.FPars[Cor.i_start_zoom_FP,Cor.i_col_x]) and \
       not np.isnan(IO.FPars[Cor.i_stop_zoom_FP,Cor.i_col_x]):
        itmin = np.nanargmin(IO.FPars[:,0])
        itmax = np.nanargmax(IO.FPars[:,0])
        tmin  = np.nanmax([IO.FPars[Cor.i_start_zoom_FP,Cor.i_col_x],IO.FPars[itmin,Cor.i_col_x]])        
        tmax  = np.nanmin([IO.FPars[Cor.i_stop_zoom_FP,Cor.i_col_x],IO.FPars[itmax,Cor.i_col_x]])
    IO.Get_Labels()
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (FParPlotWidth,FParPlotHeight),dpi=mydpi)
    iPlot = 0
    for Key in Cor.ModelParKeys:
        axis = fig.add_subplot(6,1,iPlot+1)
        if Cor.RheoType == 'Jp_Jpp' or iPlot == 0:
            StdErrs = np.ones(len(IO.FPars))*np.nan
            for i in range(0,len(StdErrs),Cor.Update_Inval): StdErrs[i] = IO.FPars[i,2+2*iPlot+1]
            if Cor.i_PlotErrBars == 1:
                axis.errorbar(IO.FPars[:,Cor.i_col_x],IO.FPars[:,2+2*iPlot],StdErrs,c='r')
            else:
                axis.plot(    IO.FPars[:,Cor.i_col_x],IO.FPars[:,2+2*iPlot],'.-',c='r',\
                          markersize=3,linewidth = 0.5)
        else :
            if iPlot == 0: 
                axis.plot(IO.FPars[:,Cor.i_col_x],IO.FPars[:,2],'.-',c='r'\
                          ,markersize=3,linewidth = 0.5)
            else:     
                axis.plot(IO.FPars[:,Cor.i_col_x],IO.FPars[:,2+10+iPlot-1],'.-',c='r',\
                          markersize=3,linewidth = 0.5)

        if not np.isnan(IO.FPars[Cor.i_start_zoom_FP,Cor.i_col_x]) and \
           not np.isnan(IO.FPars[Cor.i_stop_zoom_FP,Cor.i_col_x]):
            if tmax > tmin:
                leftlim  = tmin - 0.05*(tmax-tmin)
                rightlim = tmax + 0.05*(tmax-tmin)
                axis.set_xlim(left = leftlim,right=rightlim)
        axis.tick_params(labelsize=7,direction='in')
        axis.set_ylabel(IO.Graph_Labels[Key],fontsize=8)
        axis.axes.xaxis.set_ticklabels([])
        iPlot += 1

    axis = fig.add_subplot(6,1,6)
    axis.plot(IO.FPars[:,Cor.i_col_x],IO.FPars[:,-1],'.-',c='r',markersize=3,linewidth = 0.5)
    if not np.isnan(IO.FPars[Cor.i_start_zoom_FP,Cor.i_col_x]) and \
       not np.isnan(IO.FPars[Cor.i_stop_zoom_FP,Cor.i_col_x]):
        if tmax > tmin:
            leftlim  = tmin - 0.05*(tmax-tmin)
            rightlim = tmax + 0.05*(tmax-tmin)
            axis.set_xlim(left = leftlim,right=rightlim)

    axis.tick_params(labelsize=7,direction='in')
    if Cor.vs_time_datapoint == 'time'     : axis.set_xlabel('time [' + Cor.TimeUnit+']',fontsize=9)
    if Cor.vs_time_datapoint == 'datapoint': axis.set_xlabel('number',fontsize=9)
    axis.set_ylabel('$\chi^{2}$' ,fontsize=9)
    
    if len(Cor.InfoString) > 0: 
        suptitletext = Cor.InfoString
    else : suptitletext = ''    
    if Cor.ImportFormat == 'from QSoft_new': 
        suptitletext +=  '\n' + Cor.SourceFilePathstr + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + Cor.SourceFilePathstr
    if Cor.DfRatType == 'none'     : suptitletext += '   DfR \u2192 none'      
    if Cor.DfRatType == 'Jp'       : suptitletext += '   DfR \u2192 J\''      
    if Cor.DfRatType == 'betap'    : suptitletext += '   DfR \u2192 \u03B2\''      
    if Cor.DfRatType == 'Jp_betap' : suptitletext += '   DfR \u2192 J\',\u03B2\''     
 
    fig.suptitle(suptitletext,fontsize = 8)
    fig.tight_layout(); fig.savefig(os.getcwd()+'/tmp/FPars.png',dpi=200)

    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); 
    canvas.get_tk_widget().grid(row=0,column=0,columnspan=7,sticky='NW')
    fig.canvas.mpl_connect('button_press_event'  ,onclick_FP)
    fig.canvas.mpl_connect('button_release_event',onrelease_FP)
    # fig.canvas
    
    FPs_Hide_1_Btn = tk.Button(cntr,text ='Hide Point',command=Hide_1_FP)
    FPs_Hide_1_Btn.grid(row=1,column=0,sticky='W')
    FPs_Hide_Range_Btn = tk.Button(cntr,text ='Hide Range',command=Hide_Range_FP)
    FPs_Hide_Range_Btn.grid(row=1,column=1, sticky='W')
    FPs_Unhide_Btn = tk.Button(cntr,text='Unhide',command=Unhide_FP)
    FPs_Unhide_Btn.grid(row=1,column=2,sticky='W')
    FPs_Zoom_Btn = tk.Button(cntr,text ='Zoom',command=Zoom_FP)
    FPs_Zoom_Btn.grid(row=1,column=3, sticky='W')
    FPs_UnZoom_Btn = tk.Button(cntr,text ='Unzoom',command=UnZoom_FP)
    FPs_UnZoom_Btn.grid(row=1,column=4,sticky='W')
    Graph_to_Clpbd_Btn = tk.Button(cntr,text =' Graph \u2192 Clipbd',command=Graph2Clpbd)
    Graph_to_Clpbd_Btn.grid(row=2,column=0,sticky='W')
    Vals_to_Clpbd_Btn = tk.Button(cntr,text ='Vals \u2192 Clipbd',command=Vals2Clpbd)
    Vals_to_Clpbd_Btn.grid(row=2,column=1,sticky='W')
    tk.Button(cntr,text ='Clear',command=Clear_Fits).grid(row=2,column=2,sticky='W')
    if Cor.DfRatType != 'none': PlotJppometas(JppometasFrame)
    else : JppometasFrame.grid_forget()
    
def openRndNoise(): RndNoise.RndNoise_Start()
def openchi2_Landscape(): chi2_Landscape.chi2_Landscape_Start()


def AboutMessage():
    def callback(url): webbrowser.open_new(url)
    AboutWin = tk.Toplevel(); AboutWin.title('About'); AboutWin.iconbitmap('QTM.ICO')
    AboutText = tk.Label(AboutWin, text='DfR-QTM was written by Diethelm Johannsmann, Philipp Sievers,\n'\
       'Ilya Reviakine, Judith Petri, and Arne Langhoff. \n Feedback is appreciated https://www.pc.tu-clausthal.de')
    AboutText.pack()
    AboutText.bind('<Button-1>', lambda e: callback('https://www.pc.tu-clausthal.de/en/research/qcm-modeling'))
    AboutWinbutton = tk.Button(AboutWin, text='OK', command=AboutWin.destroy)
    AboutWinbutton.pack(pady=10, padx=10, ipadx=20, side='bottom') 
    
def MakeParsFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()
    f_fund_SV  = tk.StringVar(cntr,np.round(Cor.f_fund /1e6 ,2))
    f_cen_SV   = tk.StringVar(cntr,np.round(Cor.f_cen  /1e6 ,2))
    rho_SV     = tk.StringVar(cntr,np.round(Cor.SetPars['rho'    ],2))
    rhoBulk_SV = tk.StringVar(cntr,np.round(Cor.SetPars['rhoBulk'],2))
    etaBulk_SV = tk.StringVar(cntr,np.round(Cor.SetPars['etaBulk'],2))
    if Cor.FitDone == 'yes': fg = 'black'
    else                   : fg = 'grey'
    
    def EnterModelPars(event,Key):
        if Key in Cor.ModelParKeys:
            string = ModelPars_SVs[Key].get(); string.strip()
            if '\u00b1' in string: 
                index = string.find('\u00b1'); string = string[:index]
            try: Cor.ModelPars[Key] = np.float64(string)
            except: print(Key,string)
        Cor.Adjusted_to_Bounds = Cor.Adjust_Pars_to_Bounds()    
        Cor.FitDone = 'no'; Cor.Write_Config()
        MakeParsFrame(ParsFrame)
        PlotSingle(PlotSingleFrame)

    def incdec(val,pm):
        if pm=='+':
            if val>0: val*=1.5
            if abs(val) <= 1e-7: val+=1.
            if val<0: val/=1.5
        elif pm=='-':
            if val>0: val/=1.5
            if abs(val) <= 1e-7: val-=1.
            if val<0: val*=1.5
        else: 
            try: val = np.float64(pm)
            except: pass
        Cor.FitDone = 'no'; Cor.Write_Config()
        return val  
    
    def Pars_to_Clpbd():
        c_names=['Parameter','Value','StandardError']
        Parsdf = pd.DataFrame({},columns = c_names)
        for iKey,Key in enumerate(Cor.ModelParKeys):
            Parsdf.at[iKey,'Parameter']  = IO.header_Labels_Model[Key]
            Parsdf.at[iKey,'Value'] = Cor.ModelPars[Key]
            Parsdf.at[iKey,'StandardError'] = Cor.ModelParStdErrs[Key]
        for iKey,Key in enumerate(Cor.RheoParKeys):
            Parsdf.at[iKey+5,'Parameter']  = IO.header_Labels_Rheo[Key]
            Parsdf.at[iKey+5,'Value'] = Cor.RheoPars[Key]
        Parsdf.at[10,'Parameter']  = 'chi2'
        Parsdf.at[10,'Value'] = Cor.chi2
        Parsdf.to_clipboard(excel=True,sep=None,index=False,\
                            header='Parameter \t Value \t StandardError')
         
    def incdec_t(): 
        Cor.ModelPars['t'] = incdec(Cor.ModelPars['t'],ModelPars_SVs['t'].get())
        Cor.Adjusted_to_Bounds = Cor.Adjust_Pars_to_Bounds(); Cor.Write_Config()
        MakeParsFrame(cntr); MakeFitFrame(FitFrame); PlotSingle(PlotSingleFrame)
    def incdec_Par1(): 
        Cor.ModelPars['Par1'] = incdec(Cor.ModelPars['Par1'],ModelPars_SVs['Par1'].get())
        Cor.Adjusted_to_Bounds = Cor.Adjust_Pars_to_Bounds(); Cor.Write_Config(); 
        MakeParsFrame(cntr); PlotSingle(PlotSingleFrame) 
    def incdec_Par2(): 
        Cor.ModelPars['Par2'] = incdec(Cor.ModelPars['Par2'],ModelPars_SVs['Par2'].get())
        Cor.Adjusted_to_Bounds = Cor.Adjust_Pars_to_Bounds();Cor.Write_Config();
        MakeParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_PLExp1(): 
        Cor.ModelPars['PLExp1'] = incdec(Cor.ModelPars['PLExp1'],ModelPars_SVs['PLExp1'].get())
        Cor.Adjusted_to_Bounds = Cor.Adjust_Pars_to_Bounds(); Cor.Write_Config(); 
        MakeParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_PLExp2(): 
        Cor.ModelPars['PLExp2'] = incdec(Cor.ModelPars['PLExp2'],ModelPars_SVs['PLExp2'].get())
        Cor.Adjusted_to_Bounds = Cor.Adjust_Pars_to_Bounds(); Cor.Write_Config(); 
        MakeParsFrame(cntr); PlotSingle(PlotSingleFrame)
    
    def enter_RheoType(event): 
        RheoLabel_both_in = event.widget.get()
        for i,RheoLabel_both in enumerate(Cor.RheoLabels_both):
            if RheoLabel_both_in == RheoLabel_both: 
                Cor.RheoType = Cor.RheoTypes[i]
        Cor.FitDone = 'no'; Cor.Write_Config()
        Cor.ConvertFPars()
        Cor.RheoPars['Par1'],Cor.RheoPars['Par2'],Cor.RheoPars['PLExp1'],Cor.RheoPars['PLExp2'] = \
            Cor.RheoPars_from_ModelPars(Cor.RheoType)
        IO.Make_headers()
        PlotFPars(PlotFParsFrame)
        PlotSingle(PlotSingleFrame)
        MakeParsFrame(cntr)
       
    def enter_RefType(event): 
        RefLabel_in = event.widget.get()
        for i,RefLabel in enumerate(Cor.RefLabels):
            if RefLabel_in == RefLabel: 
                Cor.RefType = Cor.RefTypes[i]
        Cor.FitDone = 'no'; Cor.Write_Config()
        Cor.Simulate(); PlotSingle(PlotSingleFrame)
 
        MakeParsFrame(cntr)

    def enter_DfRatType(event): 
        DfRatLabel_in = event.widget.get()
        for i,DfRatLabel in enumerate(Cor.DfRatLabels):
            if DfRatLabel_in == DfRatLabel: 
                Cor.DfRatType = Cor.DfRatTypes[i]
        if Cor.DfRatTypes == 'Jp_betap' : 
            Cor.IncInFits['Par1'] = 0; Cor.IncInFits['PLExp1'] = 0; 
        if Cor.DfRatTypes == 'Jp' : 
            Cor.IncInFits['Par1'] = 0; Cor.IncInFits['PLExp1'] = 1; 
        if Cor.DfRatTypes == 'betap' : 
            Cor.IncInFits['Par1'] = 1; Cor.IncInFits['PLExp1'] = 0; 
        if Cor.DfRatTypes == 'none' : 
            Cor.IncInFits['Par1'] = 1; Cor.IncInFits['PLExp1'] = 1; 
        Cor.FitDone = 'no'; Cor.Write_Config()
        if Cor.DfRatType != 'none' : 
            JppometasFrame.grid(row=2,column=0,sticky='NW')
        else : JppometasFrame.grid_forget()

        MakeParsFrame(cntr)

    def EnterSetPars(event,WhichStr,Key):
        if WhichStr == 'f_fund': 
            string = f_fund_SV.get(); string.strip()
            try    : Cor.f_fund = np.float64(string)*1e6
            except : print(Key,string)
        if WhichStr == 'f_cen': 
            string = f_cen_SV.get(); string.strip()
            try    : Cor.f_cen = np.float64(string)*1e6
            except : print(Key,string)
        if WhichStr == 'rho': 
            string = rho_SV.get(); string.strip()
            try    : Cor.SetPars['rho'] = np.float64(string)
            except : print(Key,string)
        if WhichStr == 'rhoBulk': 
            string = rhoBulk_SV.get(); string.strip()
            try    : Cor.SetPars['rhoBulk'] = np.float64(string)
            except : print(Key,string)
        if WhichStr == 'etaBulk': 
            string = etaBulk_SV.get(); string.strip()
            try    : Cor.SetPars['etaBulk'] = np.float64(string)
            except : print(Key,string)

        Cor.Write_Config(); Cor.Read_Config(); Cor.FitDone = 'no'; MakeParsFrame(cntr)
        PlotSingle(PlotSingleFrame);
        if WhichStr == 'f_fund': 
            MakeDfDGbynsFrame(DfDGbynsFrame); PlotShifts(PlotShiftsFrame);

    def Check_t():
        Calc_nFPars();Cor.IncInFits['t'   ]  =int(IncInFit_IVs['t'     ].get());Cor.FitDone='no';Cor.Write_Config()
    def Check_Par1():      
        Calc_nFPars();Cor.IncInFits['Par1']  =int(IncInFit_IVs['Par1'  ].get());Cor.FitDone='no';Cor.Write_Config()
    def Check_Par2():  
        Calc_nFPars();Cor.IncInFits['Par2']  =int(IncInFit_IVs['Par2'  ].get());Cor.FitDone='no';Cor.Write_Config()
    def Check_PLExp1():     
        Calc_nFPars();Cor.IncInFits['PLExp1']=int(IncInFit_IVs['PLExp1'].get());Cor.FitDone='no';Cor.Write_Config()
    def Check_PLExp2():     
        Calc_nFPars();Cor.IncInFits['PLExp2']=int(IncInFit_IVs['PLExp2'].get());Cor.FitDone='no';Cor.Write_Config()
    
    ModelPars_SVs_List = []; SetPar_SVs_List = []; IncInFit_IVs_List = [] 
    ModelPars_List = []; IncInFit_List = []
    for Key in Cor.SetParKeys:
        SetPar_SVs_List.append(tk.StringVar(cntr,Cor.SetPars[Key]))
    for Key in Cor.ModelParKeys:
        if Cor.FitDone == 'no':
            ModelPars_SVs_List.append(tk.StringVar(cntr,np.round(Cor.ModelPars[Key],5)))
        ModelPars_List.append(Cor.ModelPars[Key])
    for Key in Cor.ModelParKeys:
        IncInFit_IVs_List.append(tk.IntVar(cntr,Cor.IncInFits[Key]))
        IncInFit_List.append(Cor.IncInFits[Key])

    for Key in Cor.ModelParKeys:
        if not np.isnan(Cor.ModelParStdErrs[Key]) and Cor.FitDone == 'yes':
            ModelPars_SVs_List.append(tk.StringVar(cntr,str(np.round(Cor.ModelPars[Key],3))+ '\u00b1' + \
                      str(np.round(Cor.ModelParStdErrs[Key],5))))
        else: 
            ModelPars_SVs_List.append(tk.StringVar(cntr,str(np.round(Cor.ModelPars[Key],3))))
    ModelPars_SVs = dict(zip(Cor.ModelParKeys ,ModelPars_SVs_List   ))
    IncInFit_IVs  = dict(zip(Cor.ModelParKeys,IncInFit_IVs_List))
    Sbw = 16

    tk.Label(cntr,width=11,text='f\u2080 [MHz]',anchor='e').grid(row=0,column=0,sticky='E')
    f_fund_Entry = tk.Entry(cntr,width=5,text=f_fund_SV)
    f_fund_Entry.grid(row=0,column=1,sticky='W')
    f_fund_Entry.bind('<Return>',lambda event: EnterSetPars(event,'f_fund',''))
    
    tk.Label(cntr,width=11,text='f_cen [MHz]',anchor='e').grid(row=1,column=0,sticky='E')
    f_cen_Entry = tk.Entry(cntr,width=5,text=f_cen_SV)
    f_cen_Entry.grid(row=1,column=1,sticky='W')
    f_cen_Entry.bind('<Return>',lambda event: EnterSetPars(event,'f_cen',''))

    tk.Label(cntr,width=11,text=u'\u03C1 [g/cm\u00b3]',anchor='e').grid(row=2,column=0,sticky='E')
    rho_Entry = tk.Entry(cntr,width=5,text=rho_SV)
    rho_Entry.grid(row=2,column=1,sticky='W')
    rho_Entry.bind('<Return>',lambda event: EnterSetPars(event,'rho',''))
    
    tk.Label(cntr,width=11,text=u'\u03C1Bulk [g/cm\u00b3]',anchor='e').grid(row=3,column=0,sticky='E')
    rhoBulk_Entry = tk.Entry(cntr,width=5,text=rhoBulk_SV)
    rhoBulk_Entry.grid(row=3,column=1,sticky='W')
    rhoBulk_Entry.bind('<Return>',lambda event: EnterSetPars(event,'rhoBulk',''))
    
    tk.Label(cntr,width=11,text='\u03B7Bulk [mPa s]',anchor='e').grid(row=4,column=0,sticky='E')  
    etaBulk_Entry = tk.Entry(cntr,width=5,text=etaBulk_SV)
    etaBulk_Entry.grid(row=4,column=1,sticky='W')
    etaBulk_Entry.bind('<Return>',lambda event: EnterSetPars(event,'etaBulk',''))
    
    tk.Label(cntr,text='th_f [nm]').grid(row=0,column=2)
    vals=(ModelPars_SVs['t'].get(),'+','-')
    t_Entry = tk.Spinbox(cntr,width=Sbw,text=ModelPars_SVs['t'],fg=fg,wrap=True,\
                         values=vals,command=incdec_t)
    t_Entry.grid(row=0,column=3,sticky='W')
    t_Entry.bind('<Return>',lambda event: EnterModelPars(event,'t'))

    iRheoType = Cor.iRheoTypes[Cor.RheoType]
    tk.Label(cntr,text=Cor.RheoLabels_re[0]).grid(row=1,column=2)
    vals=(ModelPars_SVs['Par1'].get(),'+','-')
    Jp_Entry = tk.Spinbox(cntr,width=Sbw,text=ModelPars_SVs['Par1'],fg=fg,wrap=True,\
                              values=vals,command=incdec_Par1)

    Jp_Entry.grid(row=1,column=3,sticky='W')
    Jp_Entry.bind('<Return>',lambda event: EnterModelPars(event,'Par1'))

    tk.Label(cntr,text=Cor.RheoLabels_im[0]).grid(row=2,column=2)
    vals=(ModelPars_SVs['Par2'].get(),'+','-')
    Jpp_Entry = tk.Spinbox(cntr,width=Sbw,text=ModelPars_SVs['Par2'],fg=fg,wrap=True,\
                           values=vals,command=incdec_Par2)
    Jpp_Entry.grid(row=2,column=3,sticky='W')
    Jpp_Entry.bind('<Return>',lambda event: EnterModelPars(event,'Par2'))

    tk.Label(cntr,text=u'\u03B2\'').grid(row=3,column=2)
    vals=(ModelPars_SVs['PLExp1'].get(),'+','-')
    Jp_PLexpt_Entry = tk.Spinbox(cntr,width=Sbw,text=ModelPars_SVs['PLExp1'],fg=fg,wrap=True,\
                                 values=vals,command=incdec_PLExp1)
    Jp_PLexpt_Entry.grid(row=3,column=3,sticky='W')
    Jp_PLexpt_Entry.bind('<Return>',lambda event: EnterModelPars(event,'PLExp1'))        

    tk.Label(cntr,text=u'\u03B2\'\'').grid(row=4,column=2)
    vals=(ModelPars_SVs['PLExp2'].get(),'+','-')
    Jpp_PLexpt_Entry = tk.Spinbox(cntr,width=Sbw,text=ModelPars_SVs['PLExp2'],fg=fg,wrap=True,\
                                  values=vals,command=incdec_PLExp2)
    Jpp_PLexpt_Entry.grid(row=4,column=3,sticky='W')
    Jpp_PLexpt_Entry.bind('<Return>',lambda event: EnterModelPars(event,'PLExp2'))

    RheoPar_cb = tk.ttk.Combobox(cntr,width=11,state='readonly',\
        text=Cor.RheoLabels_both[iRheoType],values=Cor.RheoLabels_both)
    RheoPar_cb.grid(row=5,column=5,sticky='W')
    RheoPar_cb.current(iRheoType)
    RheoPar_cb.bind('<<ComboboxSelected>>',enter_RheoType)
    
    tk.Checkbutton(cntr,variable=IncInFit_IVs['t'     ],command=Check_t     ).grid(row=0,column=4)
    tk.Checkbutton(cntr,variable=IncInFit_IVs['Par2'  ],command=Check_Par2  ).grid(row=2,column=4)
    tk.Checkbutton(cntr,variable=IncInFit_IVs['PLExp2'],command=Check_PLExp2).grid(row=4,column=4)
    
    if Cor.DfRatType == 'Jp_betap' :
        Cor.IncInFits['Par1'] = 0; Cor.IncInFits['PLExp1'] = 0; Cor.Write_Config();

    if Cor.DfRatType == 'betap' :
        Cor.IncInFits['Par1'] = 1; Cor.IncInFits['PLExp1'] = 0; Cor.Write_Config();
        IncInFit_IVs_List[1] = tk.IntVar(cntr,Cor.IncInFits['Par1'])
        IncInFit_IVs_List[3] = tk.IntVar(cntr,Cor.IncInFits['PLExp1'])
        IncInFit_IVs  = dict(zip(Cor.ModelParKeys,IncInFit_IVs_List))

        tk.Checkbutton(cntr,variable=IncInFit_IVs['Par1'],command=Check_Par1  ).grid(row=1,column=4)

    if Cor.DfRatType == 'Jp' :
        Cor.IncInFits['Par1'] = 0; Cor.IncInFits['PLExp1'] = 1; Cor.Write_Config();
        IncInFit_IVs_List[1] = tk.IntVar(cntr,Cor.IncInFits['Par1'])
        IncInFit_IVs_List[3] = tk.IntVar(cntr,Cor.IncInFits['PLExp1'])
        IncInFit_IVs  = dict(zip(Cor.ModelParKeys,IncInFit_IVs_List))
        tk.Checkbutton(cntr,variable=IncInFit_IVs['PLExp1'],command=Check_PLExp1).grid(row=3,column=4)

    if Cor.DfRatType == 'none':
        tk.Checkbutton(cntr,variable=IncInFit_IVs['Par1'  ],command=Check_Par1  ).grid(row=1,column=4)
        tk.Checkbutton(cntr,variable=IncInFit_IVs['PLExp1'],command=Check_PLExp1).grid(row=3,column=4)

    Cor.RheoPars['Par1'],Cor.RheoPars['Par2'],Cor.RheoPars['PLExp1'],Cor.RheoPars['PLExp2'] = \
        Cor.RheoPars_from_ModelPars(Cor.RheoType) 
    Par1Label = Cor.RheoLabels_re[iRheoType]+ ': ' + str(np.round(Cor.RheoPars['Par1'],3))
    tk.Label(cntr,text=Par1Label).grid(row=1,column=5,sticky='W')
    Par2Label = Cor.RheoLabels_im[iRheoType]+ ': ' + str(np.round(Cor.RheoPars['Par2'],3))
    tk.Label(cntr,text=Par2Label).grid(row=2,column=5,sticky='W')
    PLExp1Label = u'\u03B2\''+ ': ' + str(np.round(Cor.RheoPars['PLExp1'],3))
    tk.Label(cntr,text=PLExp1Label).grid(row=3,column=5,sticky='W')
    PLExp2Label = u'\u03B2\'\''+ ': ' + str(np.round(Cor.RheoPars['PLExp2'],3))
    tk.Label(cntr,text=PLExp2Label).grid(row=4,column=5,sticky='W')

    Cor.Calc_chi2()
    if not np.isnan(Cor.chi2):
        if Cor.chi2 < 1e9: 
            tk.Label(cntr,width=11,text=' \u03c7\u00b2 ' + str(np.round(Cor.chi2,2))).\
                grid(row=5,column=0,columnspan=2,sticky='W')
        else: 
            tk.Label(cntr,width=11,text=' \u03c7\u00b2 ').grid(row=5,column=0,columnspan=2,sticky='W')
    else:   tk.Label(cntr,width=11,text=' \u03c7\u00b2 ').grid(row=5,column=0,columnspan=2,sticky='W')
    tk.Button(cntr,text ='\u2192 Clipboard',command=Pars_to_Clpbd,anchor='n').\
        grid(row=5,column=1,columnspan=2,sticky='W') 
        
    iDfRatType = Cor.iDfRatTypes[Cor.DfRatType]
    DfRat_cb = tk.ttk.Combobox(cntr,width=15,state='readonly',\
        text=Cor.DfRatLabels[iDfRatType],values=Cor.DfRatLabels)
    DfRat_cb.grid(row=5,column=3,sticky='W')
    DfRat_cb.current(iDfRatType)
    DfRat_cb.bind('<<ComboboxSelected>>',enter_DfRatType)

    iRefType = Cor.iRefTypes[Cor.RefType]
    Ref_cb = tk.ttk.Combobox(cntr,width=12,state='readonly',\
        text=Cor.RefLabels[iRefType],values=Cor.RefLabels)
    Ref_cb.grid(row=0,column=5,sticky='W')
    Ref_cb.current(iRefType)
    Ref_cb.bind('<<ComboboxSelected>>',enter_RefType)

def MakeDfDGbynsFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()
    global DD_DGbyn_Labels 
    DD_DGbyn_Labels = ['\u0394\u0393/n','\u0394D']

    def NewBLine():
        if os.path.isfile(os.getcwd()+'/tmp/Shifts_for_unhide.qtm'): 
            Shifts_for_Unhide = np.loadtxt(os.getcwd()+'/tmp/Shifts_for_unhide.qtm',skiprows=1)
        else : Shifts_for_Unhide = np.ones((1,4*Cor.novt+3))*np.nan
        for iovt in range(Cor.novt):
            Shifts_for_Unhide[:,2+4*iovt  ] -= Cor.Dfcbyns[iovt].real
            Shifts_for_Unhide[:,2+4*iovt+1] -= Cor.Dfcbyns[iovt].imag
            Shifts_for_Unhide[:,2+4*iovt+2] -= Cor.Dfcbyns[iovt].real
            Shifts_for_Unhide[:,2+4*iovt+3] -= Cor.Dfcbyns[iovt].imag
        np.savetxt(os.getcwd()+'/tmp/Shifts_for_unhide.qtm',Shifts_for_Unhide,header=IO.header_Shifts,delimiter='\t',newline='\n')

        for iovt in range(Cor.novt):
            IO.Shifts[:,2+4*iovt  ] -= Cor.Dfcbyns[iovt].real
            IO.Shifts[:,2+4*iovt+1] -= Cor.Dfcbyns[iovt].imag
            IO.Shifts[:,2+4*iovt+2] -= Cor.Dfcbyns[iovt].real
            IO.Shifts[:,2+4*iovt+3] -= Cor.Dfcbyns[iovt].imag
            Cor.Dfbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt  ]
            Cor.DGbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt+1]
        Cor.Dfcbyns = Cor.Dfbyns + 1j * Cor.DGbyns; MakeDfDGbynsFrame(DfDGbynsFrame)
        IO.Make_headers(); np.savetxt(os.getcwd()+'/tmp/Shifts.qtm',IO.Shifts,header=IO.header_Shifts,delimiter='\t',newline='\n')
        PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
        Cor.i_start_avg = 0; Cor.i_stop_avg = 0;
        Cor.Write_Config()

    def Enter_ContrPars_DfDGbyns(event,iovt,WhichStr,Key):
        if WhichStr == 'Df':
            string = Dfbyn_SVs[iovt].get(); string.strip()
            try: Cor.Dfbyns[iovt] = np.float64(string);
            except: pass
        if WhichStr == 'DG':
            if Cor.DD_DGbyn == 'DGbyn': 
                string = DGbyn_SVs[iovt].get(); string.strip()
                try: Cor.DGbyns[iovt] = np.float64(string)
                except: pass
            elif Cor.DD_DGbyn == 'DD': 
                string = DD_SVs[iovt].get(); string.strip()
                try: Cor.DGbyns[iovt] = np.float64(string)*(Cor.f_fund/2*1e-6)
                except: pass

        Cor.Dfcbyns.real = Cor.Dfbyns
        Cor.Dfcbyns.imag = Cor.DGbyns
        Cor.FitDone = 'no'; Cor.Write_Config() 
        PlotSingle(PlotSingleFrame) 
        MakeDfDGbynsFrame(DfDGbynsFrame)
    def enter_DD_DGbyn(event):
        DD_DGbyn = event.widget.get()
        for i,DD_DGbyn_Label in enumerate(DD_DGbyn_Labels):
            if DD_DGbyn == DD_DGbyn_Label: Cor.DD_DGbyn = Cor.DD_DGbyn_strings[i]
        Cor.Write_Config()
        Make_Menu()
        MakeDfDGbynsFrame(DfDGbynsFrame)
        PlotShifts(PlotShiftsFrame)
        PlotSingle(PlotSingleFrame)

    def ImportFromClipboard():
        Reply = tk.messagebox.askyesnocancel('','Clear previous data, fits, and fit results?')
        if Reply == True:
            NewFile(); Root.update()
        elif Reply == None: return 
        cliptext = Root.clipboard_get()
        print(cliptext)
        lines = cliptext.splitlines()
        for iovt in range(Cor.novt):
            Cor.Dfbyns[iovt] = np.nan
            Cor.DGbyns[iovt] = np.nan
        for j in range(len(lines)):
            try: 
                nL = int(lines[j].split()[0])
                DfbynL     = float(lines[j].split()[1])
                DGbynOrDDL = float(lines[j].split()[2])
                for iovtt,n in enumerate(Cor.ns):
                    if nL == n:
                        iovt = iovtt
                        Cor.Dfbyns[iovt] = DfbynL
                        if Cor.DD_DGbyn == 'DGbyn': Cor.DGbyns[iovt] = DGbynOrDDL
                        if Cor.DD_DGbyn == 'DD':    Cor.DGbyns[iovt] = DGbynOrDDL * Cor.f_fund/2*1e-6
            except: pass
        for iovt in range(Cor.novt): 
            if not np.isnan(Cor.Dfbyns[iovt]) and not np.isnan(Cor.DGbyns[iovt]):
                Cor.OvtInc[iovt] = 1
            else: Cor.OvtInc[iovt] = 0 
        Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns     

        Cor.FitDone = 'no'; Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeDfDGbynsFrame(DfDGbynsFrame)    

    

    Dfbyn_SVs = []; DGbyn_SVs = []; DD_SVs = []; OvtInc_IVs = []
    if Cor.i_current < Cor.i_start_fit: Cor.i_current = Cor.i_start_fit 
    if Cor.i_current > Cor.i_stop_fit:  Cor.i_current = Cor.i_stop_fit 
    for iovt in range(Cor.novt):  
        if np.isnan(Cor.Dfbyns[iovt]): Dfbyn_SVs.append(tk.StringVar(cntr,''))
        else: Dfbyn_SVs.append(tk.StringVar(cntr,np.round(Cor.Dfbyns[iovt],2)))
        if np.isnan(Cor.DGbyns[iovt]): 
            DGbyn_SVs.append(tk.StringVar(cntr,''))
            DD_SVs.append(   tk.StringVar(cntr,''))
        else:     
            DGbyn_SVs.append(tk.StringVar(cntr,np.round(Cor.DGbyns[iovt],2)))
            DD_SVs.append(   tk.StringVar(cntr,np.round(Cor.DGbyns[iovt]/(Cor.f_fund/2*1e-6),2)))
        OvtInc_IVs.append(tk.IntVar(cntr,int(Cor.OvtInc[iovt])))
    if Cor.i_selec > 0 and Cor.i_selec < len(IO.Shifts) and Cor.i_stop_avrg == Cor.i_start_avrg:     
        tk.Label(cntr,text='time ' + str(np.round(IO.Shifts[Cor.i_selec,Cor.i_col_x],1))).grid(row=0,column=0)
    if Cor.i_stop_avrg > Cor.i_start_avrg and Cor.i_start_avrg < len(IO.Shifts) and Cor.i_stop_avrg < len(IO.Shifts):  
        tk.Label(cntr,text='time ' + str(np.round(IO.Shifts[Cor.i_start_avrg,Cor.i_col_x],1))+'-'+\
                           str(np.round(IO.Shifts[Cor.i_stop_avrg,Cor.i_col_x],1))   ).grid(row=0,column=0)
    tk.Label(cntr,text='\u0394f/n [Hz]').grid(row=1,column=1)
    if Cor.DD_DGbyn == 'DD'   : tk.Label(cntr,text='\u0394D [10\u207B\u2076]').grid(row=1,column=2)
    if Cor.DD_DGbyn == 'DGbyn': tk.Label(cntr,text='\u0394\u0393/n [Hz]').grid(row=1,column=2)
    
    entriesDf = []; entriesDG = []
    for iovt,n in enumerate(Cor.ns):
        tk.Label(cntr,width=6,text=str(round(n*Cor.f_fund/1e6)) + ' MHz',anchor='e').grid(row=iovt+2,column=0,sticky='E')
        entriesDf.append(tk.Entry(cntr,width=7,text=Dfbyn_SVs[iovt]))
        entriesDf[iovt].grid(row=iovt+2,column=1)
        if iovt == 0: entriesDf[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,0,'Df',''))
        if iovt == 1: entriesDf[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,1,'Df',''))
        if iovt == 2: entriesDf[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,2,'Df',''))
        if iovt == 3: entriesDf[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,3,'Df',''))
        if iovt == 4: entriesDf[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,4,'Df',''))
        if iovt == 5: entriesDf[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,5,'Df',''))
        if iovt == 6: entriesDf[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,6,'Df',''))
        if Cor.DD_DGbyn == 'DGbyn':
            entriesDG.append(tk.Entry(cntr,width=7,text=DGbyn_SVs[iovt]))
        elif Cor.DD_DGbyn == 'DD':    
            entriesDG.append(tk.Entry(cntr,width=7,text=DD_SVs[iovt]))
        entriesDG[iovt].grid(row=iovt+2,column=2)
        if iovt == 0: entriesDG[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,0,'DG',''))
        if iovt == 1: entriesDG[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,1,'DG',''))
        if iovt == 2: entriesDG[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,2,'DG',''))
        if iovt == 3: entriesDG[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,3,'DG',''))
        if iovt == 4: entriesDG[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,4,'DG',''))
        if iovt == 5: entriesDG[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,5,'DG',''))
        if iovt == 6: entriesDG[iovt].bind('<Return>',lambda event: Enter_ContrPars_DfDGbyns(event,6,'DG',''))

    def Check_ovt1():
        Cor.OvtInc[0] = int(OvtInc_IVs[0].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
    def Check_ovt2():
        Cor.OvtInc[1] = int(OvtInc_IVs[1].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
    def Check_ovt3():
        Cor.OvtInc[2] = int(OvtInc_IVs[2].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
    def Check_ovt4():
        Cor.OvtInc[3] = int(OvtInc_IVs[3].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
    def Check_ovt5():
        Cor.OvtInc[4] = int(OvtInc_IVs[4].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
    def Check_ovt6():
        Cor.OvtInc[5] = int(OvtInc_IVs[5].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
    def Check_ovt7():
        Cor.OvtInc[6] = int(OvtInc_IVs[6].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotShifts(PlotShiftsFrame)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[0],command=Check_ovt1).grid(row=2,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[1],command=Check_ovt2).grid(row=3,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[2],command=Check_ovt3).grid(row=4,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[3],command=Check_ovt4).grid(row=5,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[4],command=Check_ovt5).grid(row=6,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[5],command=Check_ovt6).grid(row=7,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[6],command=Check_ovt7).grid(row=8,column=3)
    
    tk.Button(cntr,text='\u2192 Ref',command=NewBLine,anchor='n').grid(row=9,column=0,sticky='N')

    tk.Button(cntr,text='Clpbd \u2192 Point',command=ImportFromClipboard,fg='blue',anchor='e')\
        .grid(row=9,column=1,columnspan=2,sticky='W')
    if Cor.DD_DGbyn == 'DGbyn':
        DD_DGbyn_cb = tk.ttk.Combobox(cntr,state='readonly',width=5,text=DD_DGbyn_Labels[0],values=DD_DGbyn_Labels); 
        DD_DGbyn_cb.current(0)
    if Cor.DD_DGbyn == 'DD':
        DD_DGbyn_cb = tk.ttk.Combobox(cntr,state='readonly',width=5,text=DD_DGbyn_Labels[1],values=DD_DGbyn_Labels); 
        DD_DGbyn_cb.current(1)
    DD_DGbyn_cb.grid(row=9,column=3,sticky='W')
    DD_DGbyn_cb.bind('<<ComboboxSelected>>',enter_DD_DGbyn)

def MakeFitFrame(cntr):
    global Fit_All_Btn
    for widget in cntr.winfo_children(): widget.destroy()
    weight_Labels = ['~n^-1','~n^-0.5','flat','~n^0.5','~n^1']
    RelWeight_DfDG_SV = tk.StringVar(cntr,Cor.RelWeight_DfDG)
    ErrDfbyn_SV = tk.StringVar(cntr,Cor.ErrDfbyn)
    Update_Inval_SV  = tk.StringVar(cntr,Cor.Update_Inval)

    def Enter_ControlPars_Fit(event,WhichStr):
        if WhichStr == 'ErrDfbyn': 
            string = ErrDfbyn_SV.get(); string.strip()
            try: 
                Cor.ErrDfbyn = np.float64(string)
                MakeFitFrame(cntr);
                Cor.Write_Config()
            except: pass    
        if WhichStr == 'RelWeight_DfDG':
            string = RelWeight_DfDG_SV.get(); string.strip()
            try: 
                Cor.RelWeight_DfDG = np.float64(string)
                Cor.FitDone = 'no'; Cor.Write_Config()
            except: pass
        
        if WhichStr == 'Update_Inval': 
            string = Update_Inval_SV.get(); string.strip()
            try: 
                Cor.Update_Inval = int(string); 
                if Cor.Update_Inval < 1: Cor.Update_Inval = 1
                Cor.Write_Config(); 
                PlotFPars(PlotFParsFrame)
            except: pass        
        MakeFitFrame(FitFrame)
        Cor.Write_Config()
        
    def enter_stat_weight(event):    
        weight = event.widget.get()
        for i,weight_Label in enumerate(weight_Labels):
            if weight == weight_Label: Cor.stat_weight = Cor.stat_weight_strings[i]
        Cor.FitDone = 'no';  Cor.Write_Config()
        MakeFitFrame(FitFrame)
        
    def checkPlotErrBars():
        Cor.i_PlotErrBars = i_PlotErrBars_IV.get(); Cor.Write_Config()
        PlotFPars(PlotFParsFrame)

    tk.Button(cntr,text ='Fit Single',command=Fit,fg='red').grid(row=2,column=2,sticky='W')
    Fit_All_Btn= tk.Button(cntr,text ='Fit All',command=Fit_All,fg='red')
    Fit_All_Btn.grid(row=3,column=2,sticky='W')

    tk.Label(cntr,text='(\u03b4f/n)_err[Hz]',anchor='w').grid(row=2,column=0,sticky='W')
    ErrDfbyn_Entry = tk.Entry(cntr,width=4,text=ErrDfbyn_SV)
    ErrDfbyn_Entry.grid(row=2,column=1,sticky='W')
    ErrDfbyn_Entry.bind('<Return>',lambda event: Enter_ControlPars_Fit(event,'ErrDfbyn'))

    tk.Label(cntr,text='Update Interval').grid(row=5,column=0,sticky='W')
    Update_Inval_Entry = tk.Entry(cntr,width=4,text=Update_Inval_SV)
    Update_Inval_Entry.grid(row=5,column=1,sticky='W')
    Update_Inval_Entry.bind('<Return>',lambda event: Enter_ControlPars_Fit(event,'Update_Inval'))
    if Cor.i_PlotErrBars == 1: i_PlotErrBars_IV = tk.IntVar(cntr,1)
    if Cor.i_PlotErrBars == 0: i_PlotErrBars_IV = tk.IntVar(cntr,0)
    tk.Checkbutton(cntr,anchor='w',text='ErrBars',variable=i_PlotErrBars_IV,\
        command=checkPlotErrBars).grid(row=5,column=2,sticky = 'W')

    tk.Label(cntr,text='RelWeight\u0394\u0393,\u0394f').grid(row=3,column=0,sticky='W')
    RelWeight_DfDG_SV_Entry = tk.Entry(cntr,width=4,text=RelWeight_DfDG_SV)
    RelWeight_DfDG_SV_Entry.grid(row=3,column=1,sticky='W')
    RelWeight_DfDG_SV_Entry.bind('<Return>',lambda event: Enter_ControlPars_Fit(event,'RelWeight_DfDG'))

    tk.Label(cntr,text='Stat Weight (n)').grid(row=4,column=0,sticky='W')
    if Cor.stat_weight == 'n^-1':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,text=weight_Labels[0],values=weight_Labels); 
        weight_cb.current(0)
    if Cor.stat_weight == 'n^-(0.5)':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,text=weight_Labels[1],values=weight_Labels); 
        weight_cb.current(1)
    if Cor.stat_weight == 'flat':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,text=weight_Labels[2],values=weight_Labels); 
        weight_cb.current(2)
    if Cor.stat_weight == 'n^(0.5)':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,text=weight_Labels[3],values=weight_Labels); 
        weight_cb.current(3)
    if Cor.stat_weight == 'n^1':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,text=weight_Labels[4],values=weight_Labels); 
        weight_cb.current(4)
    weight_cb.grid(row=4,column=1,columnspan=2,sticky='W')
    weight_cb.bind('<<ComboboxSelected>>',enter_stat_weight)

def MakeImportFrame(cntr):
    global noise_label
    for widget in cntr.winfo_children(): widget.destroy()  
    n_pre_avg_SV = tk.StringVar(cntr,Cor.n_pre_avg)

    def Enter_n_pre_avg(event):
        string = n_pre_avg_SV.get(); string.strip()
        try: Cor.n_pre_avg = int(string)
        except: print(string)
        MakeImportFrame(ImportFrame)
        Cor.Write_Config()
    
    ChannelLabels      = ['Channel 1','Channel 2','Channel 3','Channel 4']
    vs_time_datapoint_Labels = ['x: time','x: i']
    
    def Import_Shifts_Clipbrd():
        if Cor.ImportFormat == 'from AWSensors':
            tempdf=pd.read_clipboard()
            if not tempdf.empty:
                tempdf.to_csv('importtemp.txt', sep ='\t', index=False)
                Cor.SourceFilePath = 'importtemp.txt'
                IO.Import_Shifts()
                Cor.SourceFilePath = ''
                if os.path.isfile('importtemp.txt'): os.remove('importtemp.txt')
                Cor.i_selec = 0
                while All_NaNs_in_Dfcs() and Cor.i_selec < len(IO.Shifts) - 1:
                   Cor.i_selec += 1

                for iovt in range(Cor.novt): 
                    Cor.Dfbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt  ]  
                    Cor.DGbyns[iovt] = IO.Shifts[Cor.i_selec,2+4*iovt+1] * Cor.f_fund/2./1e6  
                PlotShifts(PlotShiftsFrame); 
                PlotFPars(PlotFParsFrame) 
                MakeDfDGbynsFrame(DfDGbynsFrame); PlotSingle(PlotSingleFrame)
                MakeParsFrame(ParsFrame)
                MakeImportFrame(ImportFrame) 
                Root.title('DfR-QTM:    Imported from Clipboard')
        else:
            tk.messagebox.showinfo('','Feature not yet implemented')
            return
    
    def enter_ImportFormat(event): 
        ImportFormat = event.widget.get()
        for i,ImportFormatLabel in enumerate(Cor.ImportFormats):
            if ImportFormat == ImportFormatLabel: 
                Cor.ImportFormat = Cor.ImportFormats[i]
        MakeImportFrame(ImportFrame)
        Cor.Write_Config()
       
    def enter_i_channel_Shifts(event):
        Channel = event.widget.get()
        for i,Channel_Label in enumerate(ChannelLabels):
            if Channel == Channel_Label: Cor.i_channel = i
        Cor.Write_Config()
        
    def enter_vs_time_datapoint(event):    
        vs_time_datapoint = event.widget.get()
        for i,vs_time_datapoint_Label in enumerate(vs_time_datapoint_Labels):
            if vs_time_datapoint == vs_time_datapoint_Label: Cor.vs_time_datapoint = Cor.vs_time_datapoint_strings[i]
        if Cor. vs_time_datapoint == 'time': Cor.i_col_x = 1
        else:                               Cor.i_col_x = 0 
        Cor.Write_Config()
        PlotShifts(PlotShiftsFrame)
        PlotFPars(PlotFParsFrame)

    def Check_Correct_Drift():
        if int(Correct_Drift_IV.get()) == 0: Cor.Correct_Drift = 'no'
        if int(Correct_Drift_IV.get()) == 1: Cor.Correct_Drift = 'yes'
        Cor.Write_Config()

    def enter_TimeUnit(event):
       Cor.TimeUnit = event.widget.get()
       Cor.Write_Config(); 
       PlotFPars(PlotFParsFrame); PlotShifts(PlotShiftsFrame)
       MakeImportFrame(cntr)
    
    tk.Label(cntr,text='File Type').grid(row=1,column=0,sticky='N')
    w = 18
    ImportFormat_cb = tk.ttk.Combobox(cntr,state='readonly',width=w,text=Cor.ImportFormat,values=Cor.ImportFormats);
    ImportFormat_cb.current(Cor.iImportFormats[Cor.ImportFormat])
    ImportFormat_cb.grid(row=1,column=3,rowspan=2,columnspan=2,sticky='N')
    ImportFormat_cb.bind('<<ComboboxSelected>>',enter_ImportFormat)

    if Cor.ImportFormat =='from AWSensors': 
        Import_Btn_Clpbd = tk.Button(cntr,text ='Kinetics from Clpbd',command=Import_Shifts_Clipbrd,fg='blue')
        Import_Btn_Clpbd.grid(row=2,column=0,columnspan=2,sticky='N')
        
    if Cor.ImportFormat == 'from QSoft new':
        Channel_cb = tk.ttk.Combobox(cntr,state='readonly',width=10,text=ChannelLabels[Cor.i_channel],values=ChannelLabels)
        Channel_cb.grid(row=2,column=3,sticky='N')
        Channel_cb.current(Cor.i_channel)
        Channel_cb.bind('<<ComboboxSelected>>',enter_i_channel_Shifts)

    tk.Label(cntr,text='Avg on Import').grid(row=4,column=0,columnspan=2,sticky='W')
    n_pre_avg_Entry = tk.Entry(cntr,text=n_pre_avg_SV,width=4)
    n_pre_avg_Entry.grid(row=4,column=2,sticky='W')
    n_pre_avg_Entry.bind('<Return>',lambda event: Enter_n_pre_avg(event))

    if Cor.Correct_Drift == 'yes': Correct_Drift_IV = tk.IntVar(cntr,1)
    if Cor.Correct_Drift == 'no' : Correct_Drift_IV = tk.IntVar(cntr,0)
    Correct_Drift_CBtn = tk.Checkbutton(cntr,text='Import: Comp Drift',variable=Correct_Drift_IV,command=Check_Correct_Drift)
    Correct_Drift_CBtn.grid(row=4,column=3,sticky='W')
    
    if Cor.vs_time_datapoint == 'time':
        vs_time_datapoint_cb = tk.ttk.Combobox(cntr,state='readonly',width=9,text=vs_time_datapoint_Labels[0],values=vs_time_datapoint_Labels); vs_time_datapoint_cb.current(0)
    if Cor.vs_time_datapoint == 'datapoint':
        vs_time_datapoint_cb = tk.ttk.Combobox(cntr,state='readonly',width=9,text=vs_time_datapoint_Labels[1],values=vs_time_datapoint_Labels); vs_time_datapoint_cb.current(1)
    vs_time_datapoint_cb.grid(row=5,column=0,columnspan=2,sticky='W')
    vs_time_datapoint_cb.bind('<<ComboboxSelected>>',enter_vs_time_datapoint)
    TimeUnit_label = tk.Label(cntr,text='t unit')
    TimeUnit_label.grid(row=5,column=2,columnspan=1,sticky='W')
    TimeUnit_cb = tk.ttk.Combobox(cntr,state='readonly',width=9,text=Cor.TimeUnit,values=Cor.TimeUnit_strings); 
    TimeUnit_cb.grid(row=5,column=3,columnspan=2,sticky='W')
    TimeUnit_cb.current(Cor.iTimeUnit_strings[Cor.TimeUnit])
    TimeUnit_cb.bind('<<ComboboxSelected>>',enter_TimeUnit)

    IO.Calc_rms_noise_Dfbyn()
    noise_label = tk.Label(cntr,text='(\u03b4f/n)_rms [mHz]: --')
    noise_label.grid(row=7,column=0,columnspan=4,sticky='W')
    if not np.isnan(Cor.rms_noise_Dfbyn):
        noise_label = tk.Label(cntr,text='(\u03b4f/n)_rms [mHz]: '+ str(np.round(Cor.rms_noise_Dfbyn*1e3,1)),anchor='w')
        noise_label.grid(row=7,column=0,columnspan=4,sticky='W')
    noise1Hz_label = tk.Label(cntr,text='(\u03b4f/n)_rms [mHz/Hz^0.5]: --')
    noise1Hz_label.grid(row=8,column=0,columnspan=4,sticky='W')
    if not np.isnan(Cor.rms_noise_Dfbyn_bySqrtHz):
        noise1Hz_label = tk.Label(cntr,text='(\u03b4f/n)_rms [mHz/Hz^0.5]: '+ str(np.round(Cor.rms_noise_Dfbyn_bySqrtHz*1e3,1)),anchor='w')
        noise1Hz_label.grid(row=8,column=0,columnspan=4,sticky='W')

    InfoString_SV = tk.StringVar(cntr,Cor.InfoString)
    def Enter_Info(event,WhichStr):
        if WhichStr == 'InfoString':
            string = InfoString_SV.get(); string.strip()
            try: 
                Cor.InfoString = string; Cor.Write_Config()
                PlotShifts(PlotShiftsFrame)
                PlotFPars(   PlotFParsFrame)
                PlotSingle(  PlotSingleFrame)
            except: pass 
    tk.Label(cntr,text='Info',width=4).grid(row=6,column=0,sticky='W')
    InfoString_Entry = tk.Entry(cntr,text=InfoString_SV,width=25)
    InfoString_Entry.grid(row=6,column=1,columnspan=4,sticky='W')
    InfoString_Entry.bind('<Return>',lambda event: Enter_Info(event,'InfoString'))

def NewFile():
    for Filename in os.listdir(os.getcwd()+'/tmp/'):
        os.remove(os.getcwd()+'/tmp/'+Filename) 
    if os.path.isfile(os.getcwd()+'/Defaults.qtm'): 
        shutil.copyfile(os.getcwd()+'/Defaults.qtm',os.getcwd()+'/tmp/Config.qtm')
    Cor.Read_Config(); Clear_Fits(); Clear(); Cor.FitDone = 'no'; Cor.Write_Config()
    IO.Initialize(); Update_User_Interface()
    
def OpenPrevious(i): 
    Cor.ConfigFilePath = Cor.PreviousFilePaths[i]; Cor.Write_Ini(); OpenFile()
    
def ImportPreviousSource(i): 
    Cor.SourceFilePath = Cor.PreviousSourcePaths[i]; Cor.Write_Ini(); 
    Cor.ImportFormat   = Cor.PreviousSourceFormats[i]; Cor.Write_Ini(); 
    Import_Shifts()

def OpenFileDialog():
    OpenfilePath=fd.askopenfilename(title='open Config.qtm',filetypes=[('qtm file', '.qtm')])
    if OpenfilePath == '' : return
    else :
        Cor.ConfigFilePath = os.path.dirname(Cor.ConfigFilePath) + '/Config.qtm'
        Cor.Write_Config(); Update_Previous_Filenames()
        OpenFile()
    
def OpenFile():    
    if 'Config.' in Cor.ConfigFilePath:            Source_FName = os.path.basename(Cor.ConfigFilePath)[:-10]
    if 'Shifts.' in Cor.ConfigFilePath:            Source_FName = os.path.basename(Cor.ConfigFilePath)[:-10]
    if 'Shifts_for_unhide.' in Cor.ConfigFilePath: Source_FName = os.path.basename(Cor.ConfigFilePath)[:-21]
    if 'FPars.q' in Cor.ConfigFilePath:            Source_FName = os.path.basename(Cor.ConfigFilePath)[:-9]
    if 'FPars_for_unhide.' in Cor.ConfigFilePath:  Source_FName = os.path.basename(Cor.ConfigFilePath)[:-20]
    for File in os.listdir(os.getcwd() + '/tmp'): os.remove(os.getcwd() + '/tmp/'+File)
    for Filename in os.listdir(os.path.dirname( Cor.ConfigFilePath)) : 
        Target_FN = Filename.replace(Source_FName,'')
        shutil.copyfile(os.path.dirname(Cor.ConfigFilePath)+'/'+Filename,os.getcwd()+'/tmp/'+ Target_FN)
    Cor.Read_Config(); IO.Initialize(); Update_User_Interface()         

def SaveAs():
    SaveFiledir = fd.askdirectory(initialdir=os.path.dirname(Cor.SourceFilePath))
    if SaveFiledir == '' : return
    if os.path.isdir(SaveFiledir): 
        for File in os.listdir(SaveFiledir) : os.remove(SaveFiledir + '/' + File)
    Source_FName = os.path.basename(Cor.SourceFilePath)
    if os.path.isfile(  os.getcwd()+'/tmp/'+Source_FName):
        shutil.copyfile(os.getcwd()+'/tmp/'+Source_FName,\
                           SaveFiledir +'/'+Source_FName)
    shutil.copyfile(os.getcwd()+'/tmp/Config.qtm',SaveFiledir+'/Config.qtm')
    shutil.copyfile(os.getcwd()+'/tmp/Shifts.qtm',SaveFiledir+'/Shifts.qtm')
    shutil.copyfile(os.getcwd()+'/tmp/FPars.qtm' ,SaveFiledir+'/FPars.qtm')
    shutil.copyfile(os.getcwd()+'/tmp/Shifts_for_unhide.qtm',SaveFiledir+'/Shifts_for_unhide.qtm')
    shutil.copyfile(os.getcwd()+'/tmp/FPars_for_unhide.qtm' ,SaveFiledir+'/FPars_for_unhide.qtm')
    shutil.copyfile(os.getcwd()+'/tmp/Shifts.png',SaveFiledir+'/Shifts.png')
    shutil.copyfile(os.getcwd()+'/tmp/FPars.png' ,SaveFiledir+'/FPars.png')
    
    shutil.copyfile(os.getcwd()+'/tmp/chi2LS_SinglePar.qtm' ,SaveFiledir+'/chi2LS_SinglePar.qtm')
    shutil.copyfile(os.getcwd()+'/tmp/chi2LS_SinglePar.png' ,SaveFiledir+'/chi2LS_SinglePar.png')
    shutil.copyfile(os.getcwd()+'/tmp/chi2LS_AllPars.qtm' ,SaveFiledir+'/chi2LS_AllPars.qtm')
    shutil.copyfile(os.getcwd()+'/tmp/chi2LS_AllPars.png' ,SaveFiledir+'/chi2LS_AllPars.png')
    
    
    
    # if os.path.isfile(folder+'/'+filename + '_chi2LS_SinglePar.qt2')      : shutil.copyfile(folder+'/'+filename + '_chi2LS_SinglePar.qt2'      ,Cor.CurrWD+'/tmp/chi2LS_SinglePar.qt2')
    # if os.path.isfile(folder+'/'+filename + '_chi2LS_SinglePar.png')      : shutil.copyfile(folder+'/'+filename + '_chi2LS_SinglePar.png'      ,Cor.CurrWD+'/tmp/chi2LS_SinglePar.png')
    # if os.path.isfile(folder+'/'+filename + '_chi2LS_AllPars.qt2')        : shutil.copyfile(folder+'/'+filename + '_chi2LS_AllPars.qt2'        ,Cor.CurrWD+'/tmp/chi2LS_AllPars.qt2')
    # if os.path.isfile(folder+'/'+filename + '_chi2LS_AllPars.png')        : shutil.copyfile(folder+'/'+filename + '_chi2LS_AllPars.png'        ,Cor.CurrWD+'/tmp/chi2LS_AllPars.png')   

    
    
    Cor.ConfigFilePath = SaveFiledir + '/Config.qtm'
    Cor.Write_Config(); Update_Previous_Filenames()

def Clear():
    Cor.Write_Config()
    Filenames = os.listdir(os.getcwd()+'/tmp/')
    for Filename in Filenames : 
        if Filename != 'Config.qtm' : os.remove(os.getcwd()+'/tmp/' + Filename)

def Update_Previous_Filenames():
    for j in range(Cor.n_previous-1,0,-1):Cor.PreviousFilePaths[j] = Cor.PreviousFilePaths[j-1]
    Cor.PreviousFilePaths[0] = Cor.ConfigFilePath
    Cor.Write_Ini(); Make_Menu()

def Update_Previous_Importnames():
    for j in range(Cor.n_previous-1,0,-1):
        Cor.PreviousSourcePaths[j]   = Cor.PreviousSourcePaths[j-1]
        Cor.PreviousSourceFormats[j] = Cor.PreviousSourceFormats[j-1]
    Cor.PreviousSourcePaths[0]   = Cor.SourceFilePath
    Cor.PreviousSourceFormats[0] = Cor.ImportFormat
    Cor.Write_Ini(); Make_Menu()

def Make_Menu():
    global menubar
    menubar = tk.Menu(Root); Root.config(menu=menubar) 
    file_menu = tk.Menu(menubar)
    menubar.add_cascade(  label='Open/Save/Import',menu=file_menu)
    file_menu.add_command(label='New' ,command=NewFile)
    file_menu.add_command(label='Open',command=OpenFileDialog)
    sub_menu = tk.Menu(file_menu,tearoff=0)
    sub_menu.add_command(label=Cor.PreviousFilePaths[0],command=lambda: OpenPrevious(0))
    sub_menu.add_command(label=Cor.PreviousFilePaths[1],command=lambda: OpenPrevious(1))
    sub_menu.add_command(label=Cor.PreviousFilePaths[2],command=lambda: OpenPrevious(2))
    sub_menu.add_command(label=Cor.PreviousFilePaths[3],command=lambda: OpenPrevious(3))
    sub_menu.add_command(label=Cor.PreviousFilePaths[4],command=lambda: OpenPrevious(4))
    sub_menu.add_command(label=Cor.PreviousFilePaths[5],command=lambda: OpenPrevious(5))
    sub_menu.add_command(label=Cor.PreviousFilePaths[6],command=lambda: OpenPrevious(6))
    sub_menu.add_command(label=Cor.PreviousFilePaths[7],command=lambda: OpenPrevious(7))
    sub_menu.add_command(label=Cor.PreviousFilePaths[8],command=lambda: OpenPrevious(8))
    sub_menu.add_command(label=Cor.PreviousFilePaths[9],command=lambda: OpenPrevious(9))
    file_menu.add_cascade(label='Open recent project',menu = sub_menu)
    file_menu.add_command(label='Save as...',command=SaveAs)

    file_menu.add_command(label='Import experimental kinetics',command=Import_Shifts_w_Dialog)
    sub_menu = tk.Menu(file_menu,tearoff=0)
    sub_menu.add_command(label=Cor.PreviousSourcePaths[0],command=lambda: ImportPreviousSource(0))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[1],command=lambda: ImportPreviousSource(1))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[2],command=lambda: ImportPreviousSource(2))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[3],command=lambda: ImportPreviousSource(3))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[4],command=lambda: ImportPreviousSource(4))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[5],command=lambda: ImportPreviousSource(5))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[6],command=lambda: ImportPreviousSource(6))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[7],command=lambda: ImportPreviousSource(7))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[8],command=lambda: ImportPreviousSource(8))
    sub_menu.add_command(label=Cor.PreviousSourcePaths[9],command=lambda: ImportPreviousSource(9))
    file_menu.add_cascade(label='Import recent experimental kinetics',menu = sub_menu)

    menubar.add_command(label='Random Noise',command=openRndNoise)
    menubar.add_command(label='\u03c7\u00b2 Landscape',command=openchi2_Landscape)
    
    def PreviousSession_action():
        PreviousSession = PreviousSession_var.get()
        if PreviousSession == False : Cor.Start_from = 'Start_from_Default'
        if PreviousSession == True  : Cor.Start_from = 'Start_from_Previous'
        Cor.Write_Ini()
    PreviousSession_var = tk.BooleanVar(value=Cor.Start_from=='Start_from_Previous')
    PreviousSession_menu = tk.Menu(menubar,tearoff=0)
    PreviousSession_menu.add_checkbutton(label='Reload Previous Project on Startup',\
        variable=PreviousSession_var,command=PreviousSession_action)    
    menubar.add_cascade(label='Start from Default/Previous',menu=PreviousSession_menu)

    menubar.add_command(label='About',command=AboutMessage)
    
def Vals_JPPometas_Clpbd():
    Vals_to_Clipboard(os.getcwd()+'/tmp/Jppometas.qtm',IO.header_Jppometas)
    
def Graph_JPPometas_Clpbd():
    Graph_to_Clipboard(os.getcwd()+'/tmp/Jppometas.png')

def PlotJppometas(cntr):  
    Jppometas = np.ones((len(IO.FPars),Cor.novt))*np.nan
    ModelPars_old = {}
    for Key in Cor.ModelParKeys : 
        ModelPars_old[Key] = Cor.ModelPars[Key]
    for it in range(len(IO.FPars)):
        Cor.ModelPars['Par1'] = IO.FPars[it,4]
        Cor.ModelPars['Par2'] = IO.FPars[it,6]        
        Cor.ModelPars['PLExp1'] = IO.FPars[it,8]
        Cor.ModelPars['PLExp2'] = IO.FPars[it,10]
        if not np.isnan(Cor.ModelPars['Par1'])   and not np.isnan(Cor.ModelPars['Par2'  ]) and \
           not np.isnan(Cor.ModelPars['PLExp1']) and not np.isnan(Cor.ModelPars['PLExp2']):   
            JPars_for_Check = Cor.RheoPars_from_ModelPars('Jp_Jpp')
            Js = np.ones(Cor.novt,dtype=np.complex128)*np.nan
            oms = 2.*np.pi*Cor.f_fund*Cor.ns
            for iovt,n in enumerate(Cor.ns):
                if Cor.OvtInc[iovt] == 1:
                    PLFac1 = (n*Cor.f_fund/Cor.f_cen)**JPars_for_Check[2]
                    PLFac2 = (n*Cor.f_fund/Cor.f_cen)**JPars_for_Check[3]
                    Js[iovt] = JPars_for_Check[0]*PLFac1 - 1j*JPars_for_Check[1]*PLFac2
                    Jppometas[it,iovt] = -Js[iovt].imag*1e-6 * oms[iovt] * Cor.SetPars['etaBulk']*1e-3
        for Key in Cor.ModelParKeys : 
            Cor.ModelPars[Key] = ModelPars_old[Key]

    fig = Figure(figsize = (2.5,0.9),dpi=mydpi)
    axis = fig.add_subplot(1,1,1)
    for iovt,n in enumerate(Cor.ns):
        if Cor.OvtInc[iovt] == 1:
            axis.plot(IO.FPars[:,Cor.i_col_x],Jppometas[:,iovt],c=Cor.Colors[iovt])
    axis.tick_params(labelsize=7,direction='in')
    axis.set_ylabel('$J^{\prime\prime}\omega\eta_{bulk}$',fontsize=9)
    if Cor.vs_time_datapoint == 'time'     : axis.set_xlabel('time ['+ Cor.TimeUnit+']',fontsize=6)
    if Cor.vs_time_datapoint == 'datapoint': axis.set_xlabel('number',fontsize=6)
    
    # axis.axes.xaxis.set_ticklabels([])
    fig.tight_layout(); fig.savefig(os.getcwd()+'/tmp/Jppometas.png',dpi=200)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); 
    canvas.get_tk_widget().grid(row=0,column=0,columnspan=2,sticky='NW')
    data_Jppometas = np.ones((len(Jppometas),Cor.novt+2))*np.nan
    for it in range(len(Jppometas)):
        data_Jppometas[it,0] = it
        data_Jppometas[it,1] = IO.FPars[it,Cor.i_col_x]
        for iovt in range(Cor.novt):
            data_Jppometas[it,iovt+2] = Jppometas[it,iovt]
    np.savetxt(os.getcwd()+'/tmp/Jppometas.qtm',data_Jppometas,header=IO.header_Jppometas,delimiter='\t',newline='\n')
    Vals_Clpbd_Jppometas_Btn = tk.Button(cntr,text ='Vals \u2192 Clipbd',command=Vals_JPPometas_Clpbd)
    Vals_Clpbd_Jppometas_Btn.grid(row=1,column=0,sticky='W')
    Graph_Clpbd_Jppometas_Btn = tk.Button(cntr,text ='Graph \u2192 Clipbd',command=Graph_JPPometas_Clpbd)
    Graph_Clpbd_Jppometas_Btn.grid(row=1,column=1,sticky='W')

def Update_User_Interface():
    MakeParsFrame(ParsFrame)
    MakeFitFrame(FitFrame)
    MakeDfDGbynsFrame(DfDGbynsFrame)
    MakeImportFrame(ImportFrame)
    PlotShifts(PlotShiftsFrame)
    PlotSingle(PlotSingleFrame)
    PlotFPars(PlotFParsFrame)
    PlotJppometas(JppometasFrame)  
    Root.title('DfR-QTM: ' + os.path.basename(Cor.SourceFilePath))

def onClose():
    try: RndNoise.RndNoiseRoot.destroy()
    except: pass
    try: chi2_Landscape.chi2_LandscapeRoot.destroy() 
    except: pass
    try: Root.destroy() 
    except: pass

def onConfigure(event):
    Cor.WindowWidth  = Root.winfo_width()
    Cor.WindowHeight = Root.winfo_height()
    Cor.WindowTop    = Root.winfo_y()
    Cor.WindowLeft   = Root.winfo_x()
    Cor.Write_Config()

Cor.Read_Ini(); 
Cor.Get_Labels(); 
Cor.Read_Config(); 
IO.Initialize(); Cor.FitDone = 'no'; Cor.Write_Config()
Root = tk.Tk()
Cor.WindowHeight += 20  # otherwise the window shrinks every time the program is closed
mydpi = Root.winfo_fpixels('1i')
# users may change the numbers below to make the window fit better to their screen 
FParPlotWidth      = 4
FParPlotHeight     = 5
DfDGbynsPlotWidth  = 2.5
DfDGbynsPlotHeight = 2.5
SinglePlotWidth    = 2.0
SinglePlotHeight   = 2.2

string_for_size =  str(Cor.WindowWidth)+'x'+\
                   str(Cor.WindowHeight)+'+'+\
                   str(Cor.WindowLeft)+'+'+\
                   str(Cor.WindowTop)
Root.geometry(string_for_size)
Root.protocol('WM_DELETE_WINDOW',onClose); Root.iconbitmap('QTM.ico'); 
Root.bind('<Configure>',onConfigure)

ParsFrame         = tk.LabelFrame(Root,text='Model' ,foreground='maroon'); ParsFrame.grid(      row=0,column=0,columnspan=2,sticky='NW')
ImportFrame       = tk.LabelFrame(Root,text='Import Options',foreground='maroon'); ImportFrame.grid(    row=0,column=2,sticky='NW')
DfDGbynsFrame     = tk.LabelFrame(Root,text='Shifts',foreground='maroon'); DfDGbynsFrame.grid(  row=1,column=0,rowspan=2,sticky='NW')
PlotSingleFrame   = tk.LabelFrame(Root,text='Single',foreground='maroon'); PlotSingleFrame.grid(row=1,column=1,sticky='NW')
FitFrame          = tk.LabelFrame(Root              ,foreground='maroon'); FitFrame.grid(       row=2,column=1,sticky='NW')
PlotShiftsFrame   = tk.LabelFrame(Root,text='Shifts & Fitted Shifts',foreground= 'maroon'); PlotShiftsFrame.grid(row=1,column=2,rowspan=3,sticky='NW')
PlotFParsFrame    = tk.LabelFrame(Root,text='Model Parameters',foreground= 'maroon'); PlotFParsFrame.grid(row=0,column=3,rowspan=4,sticky='NW')
JppometasFrame    = tk.LabelFrame(Root,text='Check for Small J\'\'',foreground= 'maroon'); 
# JppometasFrame.grid(row=2,column=0,sticky='NW')
if Cor.DfRatType != 'none' : JppometasFrame.grid(row=2,column=0,sticky='NW')
else : JppometasFrame.grid_forget()

Make_Menu()
if (Cor.Start_from == 'Start_from_Default'): NewFile()
else: Update_User_Interface()

Root.mainloop()
