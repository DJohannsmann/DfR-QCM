import numpy as np
import struct
from datetime import datetime, timedelta
from zlib import decompress
import pandas as pd
from configparser import ConfigParser
import os

def delphi_datetime_to_python(dtime): 
    delphi_epoch = datetime(1899, 12, 30)
    return delphi_epoch + timedelta(days=dtime)

class TLor: 
    @staticmethod
    def delphi_extended_to_float(extended_bytes):
        """Converts a 10-byte Delphi Extended float to Python float."""
        if len(extended_bytes) != 10:
            raise ValueError("Expected 10 bytes for Delphi Extended format")
        # Extract sign, exponent, and significand from the 10 bytes
        sign = -1 if extended_bytes[9] & 0x80 else 1
        exponent = ((extended_bytes[9] & 0x7F) << 8) | extended_bytes[8]
        mantissa = int.from_bytes(extended_bytes[:8], byteorder='little')

        # Handle special cases
        if exponent == 0 and mantissa == 0: return 0.0 * sign  # Zero
        elif exponent == 0x7FFF: 
            return float('inf') * sign if mantissa == 0 else float('nan')

        # Normal case: calculate value
        bias = 16383
        exponent -= bias
        value = sign * (mantissa / (2**63)) * (2 ** exponent)
        return value
    
    def __init__(self, data): # Extract 10 bytes for the Extended type field `fres`
        fres_bytes = data[:10]
        self.fres = self.delphi_extended_to_float(fres_bytes)
        # Unpack the remaining 8 Double values (64 bytes)
        self.Gamm, self.GMax, self.Phas, self.OffG, self.OffB, self.SloB, \
        self.SloG, self.Chsq = struct.unpack('8d', data[10:74])
    
    def __repr__(self):
        return (f"TLor(fres={self.fres}, Gamm={self.Gamm}, GMax={self.GMax}, Phas={self.Phas}, "
                f"OffG={self.OffG},OffB={self.OffB},SloB={self.SloB},SloG={self.SloG},Chsq={self.Chsq})")

class TDataR: 
    def __init__(self, data):      
        # Parse Time and TLor part
        self.Time = delphi_datetime_to_python(struct.unpack('d', data[0:8])[0])
        self.Lor = TLor(data[8:82])  
        # Parse remaining fields
        (self.Drlv, self.temp, self.humi, self.par1, self.par2, 
         self.par3, self.par4, self.par5, self.par6) = struct.unpack('9d', data[82:154])
        # Parse booleans and bytes
        self.B_FitSucc, self.BHid, self.B_Gap, self.B_Dummy = struct.unpack('4?', data[154:158])
        self.igR, self.iqR, self.ihR = struct.unpack('3B', data[158:161])
        # Parse integers
        self.idSR, self.idummy = struct.unpack('2i', data[161:169])

    def to_dict(self):
        result = vars(self)
        result.update(vars(result.pop('Lor')))
        return result
    
class QTZData():
    def __init__(self):
        self.__dataRArr = []
        self.__referenceStates = []
        self.__time0 = None
        self.__setup = {}

    def load_from_file(self, filedir: str):
        with open(filedir, 'rb') as file:
            fileformat = struct.unpack('q', file.read(8))[0]
            if fileformat == 6508916913411551043:   isCompressed = True
            elif fileformat == 6508916831572291395: isCompressed = False
            else: raise Exception('Error. Wrong File Format')
            # Cfg File
            size = struct.unpack('q', file.read(8))[0]
            ini_bytes = file.read(size)
            try:
                try: ini_str = ini_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    ini_str = ini_bytes.decode("Ansi")
                config = ConfigParser()
                config.read_string(ini_str)
                self.__setup = config
            except Exception as ExcStr:
                self.__setup = {}
                print('Cannot load configuration from qtz File')
                print(type(ExcStr), ExcStr)
            # QTZ File
            size = struct.unpack('q', file.read(8))[0]
            databytes = file.read(size) 
            if isCompressed:
                databytes = decompress(databytes)

            if not(struct.unpack('q', databytes[0:8])[0] == 3471767709297562705):
                raise Exception('Error, incorrect format')
            self.__referenceStates = [None] * 40
            for ig in range(0,2):
                for iq in range(0,2):
                    for ih in range(0,10):
                        self.__referenceStates[ig * 20 + iq * 10 + ih] = TDataR(databytes[8 + (ig * 20 + iq * 10 + ih) * 169: 8 + (ig * 20 + iq * 10 + ih+1) * 169])
                        self.__referenceStates[ig * 20 + iq * 10 + ih].igR = ig + 1
                        self.__referenceStates[ig * 20 + iq * 10 + ih].iqR = iq + 1
                        self.__referenceStates[ig * 20 + iq * 10 + ih].ihR = ih + 1
            self.__time0 = delphi_datetime_to_python(struct.unpack('d', databytes[6768:6776])[0])
            arrlength = struct.unpack('i', databytes[6780:6784])[0]
            self.__dataRArr = [None] * arrlength
            count = 0
            for i in range(arrlength):
                try:
                    self.__dataRArr[count] = TDataR(databytes[6784 + i * 169: 6784 + (i+1) * 169])
                    count += 1
                except: pass
            self.__dataRArr = self.__dataRArr[:count]
        
    def data_df(self):
        return pd.DataFrame([x.to_dict() for x in self.__dataRArr])
    def reference_df(self):
        return pd.DataFrame([x.to_dict() for x in self.__referenceStates])
    def getTime0(self): return self.__time0
    def getSetup(self): return self.__setup

def Read(Filename):
    print('Importing data from file "'+Filename+'"')
    date_format = '%Y-%m-%d %H:%M:%S'
    idat_max = 0
    DfDG_w_ts = np.ones((idat_max,15))*np.nan
    Dfbyns = np.ones((idat_max,7))*np.nan
    DGbyns = np.ones((idat_max,7))*np.nan
    PlotOvertones = np.zeros((7),dtype = int)
    if Filename.endswith('.qtz'): 
        data = QTZData()
        data.load_from_file(Filename)
        setup = data.getSetup()
        PlotOvertones[0] = setup['Main']['plotovertone(gs1)[1,1]']
        PlotOvertones[1] = setup['Main']['plotovertone(gs1)[1,2]']
        PlotOvertones[2] = setup['Main']['plotovertone(gs1)[1,3]']
        PlotOvertones[3] = setup['Main']['plotovertone(gs1)[1,4]']
        PlotOvertones[4] = setup['Main']['plotovertone(gs1)[1,5]']
        PlotOvertones[5] = setup['Main']['plotovertone(gs1)[1,6]']
        PlotOvertones[6] = setup['Main']['plotovertone(gs1)[1,7]']
        data_df = data.data_df()
        ref_df = data.reference_df()
        data_df.to_csv('tmp\Df_temp.txt')       # um tmp-Pfad ergänzt
        fres_ref = np.ones(8)*np.nan
        Gres_ref = np.ones(8)*np.nan
        ref_df.to_csv('tmp\Df_ref_temp.txt')    # um tmp-Pfad ergänzt
        f = open('tmp\Df_ref_temp.txt')         # um tmp-Pfad ergänzt
        lines = f.readlines() 
        for i in range(1,8):
            items = lines[i].split(sep = ',')
            if items[-1] != 0:
                fres_ref[i] = float(items[20])
                Gres_ref[i] = float(items[21])
        f = open('tmp\Df_temp.txt')             # um tmp-Pfad ergänzt
        lines = f.readlines()
        idat_max = 0
        for i in range(len(lines)-1):
            items = lines[1+i].split(sep = ',')
            if items[18] != '-9999.0': idat = int(items[18])
            else: idat = 0
            if idat > idat_max : idat_max = idat
        # print(str(idat_max)+' data sets found.', end='', flush=False)
        DfDG_w_ts = np.ones((idat_max,15))*np.nan
        Dfbyns = np.ones((idat_max,7))*np.nan
        DGbyns = np.ones((idat_max,7))*np.nan
        for i in range(len(lines)-1):
            if (i/len(lines)-1)%.05 == 0: print('.', end='', flush=False)
            items = lines[1+i].split(sep = ',')
            if items[-1] != 0:
                date_obj = datetime.strptime(items[1][:-4], date_format)
                time = date_obj.timestamp()
                if i == 0 : time0 = time
                time -= time0
                time_min = time/60
                iovt = int(items[17])
                if items[18] != '-9999.0': idat = int(items[18])
                else : idat = 0
                if not(items[20] == '-9999' or items[20] == '-9999.0' or \
                       items[21] == '-9999' or items[21] == '-9999.0' or \
                       items[11] == 'False' or items[12] == 'True' or 
                       PlotOvertones[iovt-1] == 0) :
                    DfDG_w_ts[idat-1,2*iovt-1] =  float(items[20]) - fres_ref[iovt]
                    DfDG_w_ts[idat-1,2*iovt  ] =  float(items[21]) - Gres_ref[iovt]
                    Dfbyns[idat-1, iovt-1]     = (float(items[20]) - fres_ref[iovt])/(2*iovt-1) # Dfbyns is 0-based, iovt is 1-based
                    DGbyns[idat-1, iovt-1]     = (float(items[21]) - Gres_ref[iovt])/(2*iovt-1) # DGbyns is 0-based, iovt is 1-based
                    DfDG_w_ts[idat-1,0]        = time_min
    else: print('Not a qtz-File, import aborted')
    f.close()                
    os.remove('tmp\Df_ref_temp.txt')        
    os.remove('tmp\Df_temp.txt')            
    return DfDG_w_ts[:,0], Dfbyns[:,:], DGbyns[:,:],PlotOvertones  
  # Quick & Dirty-Fehlerbehandlung: erster & letzter Datenpunkt waren u.U. Müll -> abschneiden