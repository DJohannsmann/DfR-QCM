import pip
def main():
    packages = ['numpy', 'numba', 'pandas', 'lmfit', 'tkinter', 'scipy', 'webbrowser']
    for package in packages:
        pip.main(['install', package])
if __name__ == "__main__":
    main()